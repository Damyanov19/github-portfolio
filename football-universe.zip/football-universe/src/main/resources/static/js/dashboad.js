// Лек ripple ефект по бутоните (UX)
(function(){
  const makeRipple = (e) => {
    const target = e.currentTarget;
    const rect = target.getBoundingClientRect();
    const span = document.createElement('span');
    const size = Math.max(rect.width, rect.height);
    span.className = 'ripple';
    span.style.width = span.style.height = size + 'px';
    span.style.left = (e.clientX - rect.left - size/2) + 'px';
    span.style.top  = (e.clientY - rect.top  - size/2) + 'px';
    target.appendChild(span);
    setTimeout(() => span.remove(), 600);
  };

  document.querySelectorAll('.btn').forEach(btn=>{
    btn.style.position = btn.style.position || 'relative';
    btn.style.overflow = 'hidden';
    btn.addEventListener('click', makeRipple);
  });
})();
/* Ripple за бутони */
.btn .ripple{
  position:absolute;
  border-radius:50%;
  transform:scale(0);
  background: rgba(255,255,255,.4);
  animation: ripple .6s linear;
  pointer-events:none;
}

@keyframes ripple{
  to{ transform:scale(4); opacity:0; }
}

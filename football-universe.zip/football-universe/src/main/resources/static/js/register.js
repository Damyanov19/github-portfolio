(function(){
  function byId(id){ return document.getElementById(id); }
  function q(name){ return document.querySelector('[name="'+name+'"]'); }

  const form       = document.querySelector('form');
  const optCreate  = byId('optCreateTeam');
  const optJoin    = byId('optJoinTeam');
  const createBlk  = byId('createTeamFields');
  const joinBlk    = byId('joinFields');
  const roleSel    = byId('roleSelect');
  const posWrap    = byId('positionWrapper');
  const posSel     = byId('positionSelect');
  const crestInput = document.querySelector('input[name="teamCrest"]');

  const MAX_FILE_BYTES = 10 * 1024 * 1024; // 10MB – синхронизирай с application.yml

  function setRequired(names, on){
    names.forEach(n=>{
      const el = q(n);
      if (!el) return;
      if (on) el.setAttribute('required','required');
      else el.removeAttribute('required');
    });
  }

  function toggleCreateJoin(){
    const create = optCreate && optCreate.checked;

    if (createBlk) createBlk.style.display = create ? '' : 'none';
    if (joinBlk)   joinBlk.style.display   = create ? 'none' : '';

    // при "създай" → изисквай полетата за отбор
    setRequired(['teamName','teamLocation','teamAgeGroupsEnum'], create);

    // при "присъедини се" → изисквай teamId/desiredRole
    setRequired(['teamId','desiredRole'], !create);

    // позиция само за PLAYER при присъединяване
    togglePosition();
  }

  function togglePosition(){
    const isJoin  = optJoin && optJoin.checked;
    const roleVal = roleSel ? roleSel.value : '';
    const showPos = isJoin && roleVal === 'PLAYER';

    if (posWrap) posWrap.style.display = showPos ? '' : 'none';
    if (posSel) {
      if (showPos) posSel.setAttribute('required','required');
      else { posSel.removeAttribute('required'); posSel.selectedIndex = 0; }
    }
  }

  function validatePasswordsMatch(){
    const p1 = q('password');
    const p2 = q('confirmPassword');
    if (!p1 || !p2) return;
    if (p1.value !== p2.value) {
      p2.setCustomValidity('Паролите не съвпадат.');
    } else {
      p2.setCustomValidity('');
    }
  }

  function validateFile(){
    if (!crestInput || !crestInput.files || !crestInput.files[0]) return true;
    const f = crestInput.files[0];
    if (f.size > MAX_FILE_BYTES) {
      alert('Емблемата е по-голяма от 10MB. Моля, качи по-малък файл.');
      return false;
    }
    return true;
  }

  document.addEventListener('DOMContentLoaded', function(){
    if (optCreate) optCreate.addEventListener('change', toggleCreateJoin);
    if (optJoin)   optJoin.addEventListener('change', toggleCreateJoin);
    if (roleSel)   roleSel.addEventListener('change', togglePosition);

    const pw  = q('password');
    const pw2 = q('confirmPassword');
    if (pw)  pw.addEventListener('input', validatePasswordsMatch);
    if (pw2) pw2.addEventListener('input', validatePasswordsMatch);

    // начално състояние (уважава стойности върнати от сървъра при грешки)
    toggleCreateJoin();
    validatePasswordsMatch();

    if (form) form.addEventListener('submit', function(e){
      form.classList.add('was-validated');
      validatePasswordsMatch();
      if (!form.checkValidity() || !validateFile()){
        e.preventDefault();
        e.stopPropagation();
      }
    });
  });
})();

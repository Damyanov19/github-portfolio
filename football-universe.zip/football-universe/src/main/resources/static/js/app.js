// [ADD] app.js – малки интеракции (tooltips, филтър, сортиране, флаш-тостове)

(() => {
  // Bootstrap tooltips
  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
    try { new bootstrap.Tooltip(el); } catch(e){}
  });

  // Toast helper (ползва се и за flash)
  const toastsHost = (() => {
    let host = document.getElementById('toasts');
    if (!host) {
      host = document.createElement('div');
      host.id = 'toasts';
      document.body.appendChild(host);
    }
    return host;
  })();

  function showToast(msg, variant='success') {
    const el = document.createElement('div');
    el.className = `toast align-items-center text-bg-${variant} fade-in`;
    el.role = 'alert';
    el.innerHTML = `<div class="d-flex">
        <div class="toast-body">${msg}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>`;
    toastsHost.appendChild(el);
    const t = new bootstrap.Toast(el, { delay: 2800 });
    t.show();
    el.addEventListener('hidden.bs.toast', () => el.remove());
  }

  // Flash -> toast (ако имаш елементи .flash-success/.flash-error в страниците)
  document.querySelectorAll('.flash-success').forEach(n => showToast(n.textContent.trim(), 'success'));
  document.querySelectorAll('.flash-error').forEach(n => showToast(n.textContent.trim(), 'danger'));

  // Табличен филтър (инпут с data-table-filter="#id-на-таблица")
  document.querySelectorAll('input[data-table-filter],input.table-filter').forEach(input => {
    const tableSel = input.getAttribute('data-table-filter') || input.dataset.tableFilter;
    const table = document.querySelector(tableSel);
    if (!table) return;
    const rows = () => [...table.tBodies[0]?.rows ?? []];
    input.addEventListener('input', () => {
      const q = input.value.toLowerCase().trim();
      rows().forEach(r => {
        const text = r.textContent.toLowerCase();
        r.style.display = !q || text.includes(q) ? '' : 'none';
      });
    });
  });

  // Сортиране по колона: добави data-sort на <th> (напр. data-sort="date"|"num"|"text")
  document.querySelectorAll('table thead th[data-sort]').forEach((th, idx) => {
    th.classList.add('cursor-pointer');
    th.addEventListener('click', () => {
      const table = th.closest('table');
      const tbody = table.tBodies[0];
      const type = th.dataset.sort || 'text';
      const dir = th.dataset.dir === 'asc' ? 'desc' : 'asc';
      th.dataset.dir = dir;

      const val = (td) => {
        const raw = td.textContent.trim();
        if (type === 'num') return parseFloat(raw.replace(',', '.')) || 0;
        if (type === 'date') {
          // опит за парс на dd.MM.yyyy HH:mm
          const p = raw.split(/[\s.:]/).map(x=>parseInt(x,10));
          if (p.length>=5) return new Date(p[2],p[1]-1,p[0],p[3],p[4]).getTime();
          const d = Date.parse(raw); return isNaN(d) ? 0 : d;
        }
        return raw.toLowerCase();
      };

      const rows = [...tbody.rows];
      rows.sort((a,b) => {
        const A = val(a.cells[idx] || {textContent:''});
        const B = val(b.cells[idx] || {textContent:''});
        return (A > B ? 1 : A < B ? -1 : 0) * (dir === 'asc' ? 1 : -1);
      });
      rows.forEach(r => tbody.appendChild(r));
    });
  });
})();

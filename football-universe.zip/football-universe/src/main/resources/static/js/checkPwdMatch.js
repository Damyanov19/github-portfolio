   function checkPwdMatch() {
              const a = document.getElementById('newPassword').value;
              const b = document.getElementById('confirmNewPassword').value;
              if (a !== b) {
                alert('Новата парола и потвърждението не съвпадат.');
                return false;
              }
              return true;
            }
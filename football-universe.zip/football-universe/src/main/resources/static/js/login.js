
(function(){
  const btn = document.getElementById('togglePass');
  const input = document.getElementById('password');
  if(btn && input){
    btn.addEventListener('click', function(){
      const isPwd = input.type === 'password';
      input.type = isPwd ? 'text' : 'password';
      btn.textContent = isPwd ? 'Скрий' : 'Покажи';
      input.focus();
    });
  }

  // HTML5 валидация за по-добър UX
  const form = document.querySelector('form.needs-validation');
  if(form){
    form.addEventListener('submit', function (e) {
      if(!form.checkValidity()){
        e.preventDefault();
        e.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  }
})();

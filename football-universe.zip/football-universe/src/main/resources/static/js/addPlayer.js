(function(){
  const roleSel = document.getElementById('roleSelectAdd');
  const posWrap = document.getElementById('positionWrapper');
  const form    = document.getElementById('addMemberForm');
  const posInp  = form ? form.querySelector('input[name="position"]') : null;

  function togglePosition(){
    const show = roleSel && roleSel.value === 'PLAYER';
    if (posWrap) posWrap.style.display = show ? '' : 'none';
    if (posInp) {
      if (show) posInp.setAttribute('required','required');
      else { posInp.removeAttribute('required'); posInp.value = ''; }
    }
  }

  if (roleSel) roleSel.addEventListener('change', togglePosition);
  document.addEventListener('DOMContentLoaded', togglePosition);
})();
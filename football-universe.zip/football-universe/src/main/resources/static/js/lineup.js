
(function () {
  "use strict";

  // Помощна: преиндексира имената във вид prefix[<idx>].field
  function reindex(tbody, prefix) {
    const rows = Array.from(tbody.querySelectorAll("tr"));
    rows.forEach((tr, idx) => {
      // Първата колонка: №
      const numCell = tr.querySelector("td:first-child");
      if (numCell) numCell.textContent = String(idx + 1);

      // Преименуваме всички input/select елементи в реда
      tr.querySelectorAll("input[name], select[name], textarea[name]").forEach((el) => {
        const oldName = el.getAttribute("name");
        if (!oldName) return;

        // търсим точно "prefix[...]" в началото на името
        const re = new RegExp(`^${prefix}\\[\\d+\\]`);
        const newName = oldName.replace(re, `${prefix}[${idx}]`);
        if (newName !== oldName) el.setAttribute("name", newName);
      });
    });
  }

  // Помощна: клонира шаблонния ред (или първия), нулира стойностите и добавя към tbody
  function addRow(tbody, prefix) {
    // 1) предпочитаме ред с data-template="<prefix>"
    let template = tbody.querySelector(`tr[data-template="${prefix}"]`);
    // 2) иначе вземаме първия истински ред (без шаблон)
    if (!template) template = tbody.querySelector("tr");

    if (!template) {
      console.warn(`Няма ред за клониране за ${prefix}`);
      return;
    }

    const clone = template.cloneNode(true);
    clone.removeAttribute("data-template");

    // Нулираме стойностите
    clone.querySelectorAll("select").forEach((s) => (s.selectedIndex = 0));
    clone.querySelectorAll('input[type="number"], input[type="text"], input[type="hidden"], textarea')
         .forEach((i) => (i.value = ""));

    // Прикачаме и преиндексираме
    tbody.appendChild(clone);
    reindex(tbody, prefix);
  }

  // Делегирано изтриване на ред
  function onRemoveClick(e) {
    const btn = e.target.closest(".remove-row");
    if (!btn) return;

    const tr = btn.closest("tr");
    const tbody = tr && tr.parentElement;
    const table = tbody && tbody.closest("table");
    if (!tbody || !table) return;

    const prefix = table.dataset.prefix; // "starters" или "bench"
    tr.remove();
    reindex(tbody, prefix);
  }

  // Инициализация
  function init() {
    // Таблици за титуляри и резерви – очакваме data-prefix="starters"/"bench"
    const startersTable = document.querySelector('table[data-prefix="starters"]');
    const benchTable = document.querySelector('table[data-prefix="bench"]');

    // Бутони за добавяне
    const addStarterBtn = document.getElementById("addStarterBtn");
    const addBenchBtn = document.getElementById("addBenchBtn");

    // Слушатели за добавяне
    addStarterBtn && addStarterBtn.addEventListener("click", () => {
      if (!startersTable) return;
      addRow(startersTable.tBodies[0], "starters");
    });

    addBenchBtn && addBenchBtn.addEventListener("click", () => {
      if (!benchTable) return;
      addRow(benchTable.tBodies[0], "bench");
    });

    // Делегирани слушатели за махане
    startersTable && startersTable.addEventListener("click", onRemoveClick);
    benchTable && benchTable.addEventListener("click", onRemoveClick);

    // Начално преиндексиране за всеки случай
    startersTable && reindex(startersTable.tBodies[0], "starters");
    benchTable && reindex(benchTable.tBodies[0], "bench");
  }

  // Стартираме след като DOM е готов
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

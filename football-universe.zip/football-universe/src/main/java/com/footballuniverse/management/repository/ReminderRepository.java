package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.ReminderEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface ReminderRepository extends JpaRepository<ReminderEntity, Long> {

    List<ReminderEntity> findAllByTeamIdOrderByDueAtAsc(Long teamId);

    List<ReminderEntity> findAllByTeamIdAndDueAtBetweenOrderByDueAtAsc(
            Long teamId, LocalDateTime start, LocalDateTime end);
}

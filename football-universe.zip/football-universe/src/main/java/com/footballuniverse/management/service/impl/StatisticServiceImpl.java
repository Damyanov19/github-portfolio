package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.dto.StatisticDto;
import com.footballuniverse.management.entity.MatchEntity;
import com.footballuniverse.management.entity.PlayerEntity;
import com.footballuniverse.management.entity.StatisticEntity;
import com.footballuniverse.management.mapper.StatisticMapper;
import com.footballuniverse.management.repository.MatchRepository;
import com.footballuniverse.management.repository.PlayerRepository;
import com.footballuniverse.management.repository.StatisticRepository;
import com.footballuniverse.management.service.StatisticService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StatisticServiceImpl implements StatisticService {

    private final StatisticRepository statisticRepository;
    private final PlayerRepository playerRepository;
    private final MatchRepository matchRepository;

    public StatisticServiceImpl(
            StatisticRepository statisticRepository,
            PlayerRepository playerRepository,
            MatchRepository matchRepository) {
        this.statisticRepository = statisticRepository;
        this.playerRepository = playerRepository;
        this.matchRepository = matchRepository;
    }

    @Override
    public StatisticDto create(StatisticDto dto) {
        PlayerEntity player = playerRepository.findById(dto.getPlayerId()).orElseThrow();
        MatchEntity match = matchRepository.findById(dto.getMatchId()).orElseThrow();
        StatisticEntity entity = StatisticMapper.toEntity(dto, match, player);
        return StatisticMapper.toDto(statisticRepository.save(entity));
    }

    @Override
    public List<StatisticDto> findAll() {
        return statisticRepository.findAll().stream()
                .map(StatisticMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public StatisticDto findById(Long id) {
        return statisticRepository.findById(id)
                .map(StatisticMapper::toDto)
                .orElseThrow();
    }

    @Override
    public void delete(Long id) {
        statisticRepository.deleteById(id);
    }
}

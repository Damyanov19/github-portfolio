package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.dto.PlayerDto;
import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.entity.PlayerEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.mapper.PlayerMapper;
import com.footballuniverse.management.repository.PlayerRepository;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.PlayerService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PlayerServiceImpl implements PlayerService {

    private final PlayerRepository playerRepo;
    private final TeamRepository teamRepo;
    private final UserRepository userRepo;
    private final PlayerMapper mapper;

    public PlayerServiceImpl(PlayerRepository playerRepo, TeamRepository teamRepo, UserRepository userRepo, PlayerMapper mapper) {
        this.playerRepo = playerRepo;
        this.teamRepo = teamRepo;
        this.userRepo = userRepo;
        this.mapper = mapper;
    }

    @Override
    public Optional<UserEntity> findById(Long id) { return userRepo.findById(id); }

    @Override
    public UserProfileDto toUserProfileDto(UserEntity u) {
        var dto = new UserProfileDto();
        dto.setUsername(u.getUsername());
        dto.setEmail(u.getEmail());
        dto.setPosition(u.getPosition());
        dto.setNumber(u.getNumber());
        if (u.getRole()!=null) dto.setRole(u.getRole().getRole().name());
        if (u.getTeam()!=null) dto.setTeamName(u.getTeam().getName());
        return dto;
    }

    @Override
    public void applyProfile(UserEntity u, UserProfileDto dto) {
        u.setEmail(dto.getEmail());
        if (dto.getPosition()!=null) u.setPosition(dto.getPosition());
        if (dto.getNumber()!=null)   u.setNumber(dto.getNumber());
    }

    @Override
    public PlayerDto createPlayer(PlayerDto dto) {
        TeamEntity team = teamRepo.findById(dto.getTeamId()).orElseThrow();
        UserEntity user = dto.getUserId() != null ? userRepo.findById(dto.getUserId()).orElse(null) : null;
        PlayerEntity player = PlayerMapper.toEntity(dto, team, user);
        return PlayerMapper.toDto(playerRepo.save(player));
    }

    @Override
    public PlayerDto updatePlayer(Long id, PlayerDto dto) {
        PlayerEntity player = playerRepo.findById(id).orElseThrow();
        TeamEntity team = teamRepo.findById(dto.getTeamId()).orElseThrow();
        UserEntity user = dto.getUserId() != null ? userRepo.findById(dto.getUserId()).orElse(null) : null;
        PlayerEntity updated = PlayerMapper.toEntity(dto, team, user);
        updated.setId(id);
        return PlayerMapper.toDto(playerRepo.save(updated));
    }

    @Override
    public void deletePlayer(Long id) {
        playerRepo.deleteById(id);
    }

    @Override
    public PlayerDto getById(Long id) {
        return playerRepo.findById(id).map(PlayerMapper::toDto).orElseThrow(EntityNotFoundException::new);
    }

    @Override
    public List<PlayerDto> getAll() {
        return playerRepo.findAll().stream().map(PlayerMapper::toDto).collect(Collectors.toList());
    }

    @Override
    public List<PlayerDto> getByTeamId(Long teamId) {
        return playerRepo.findByTeamId(teamId).stream().map(PlayerMapper::toDto).collect(Collectors.toList());
    }
}

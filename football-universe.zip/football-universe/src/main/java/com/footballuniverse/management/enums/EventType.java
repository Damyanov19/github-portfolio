package com.footballuniverse.management.enums;

public enum EventType {
    TRAINING, MATCH
}

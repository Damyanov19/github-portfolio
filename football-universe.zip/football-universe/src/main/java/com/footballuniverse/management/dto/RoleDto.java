package com.footballuniverse.management.dto;
import com.footballuniverse.management.enums.UserRoleEnums;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleDto {
    private Long id;
    private UserRoleEnums desiredRole;

    // Getters and Setters
}

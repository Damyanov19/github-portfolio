package com.footballuniverse.management.dto;

import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

@Getter
@Setter
public class TrainingDto {

    private Long id;
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
    private LocalDateTime trainingDateTime;
    private String location;
    private String focus;
    private Long teamId;

    // Getters and Setters
}

package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.MessageEntity;
import com.footballuniverse.management.entity.MessageEntity.TargetRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MessageRepository extends JpaRepository<MessageEntity, Long> {
    List<MessageEntity> findAllByTeamIdOrderByCreatedAtDesc(Long teamId);
    List<MessageEntity> findAllByTeamIdAndTargetRoleOrderByCreatedAtDesc(Long teamId, TargetRole role);
}

package com.footballuniverse.management.repository; // [ADD]

import com.footballuniverse.management.entity.PlayerMatchStatEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface PlayerMatchStatRepository extends JpaRepository<PlayerMatchStatEntity, Long> { // [ADD]

    List<PlayerMatchStatEntity> findAllByMatchId(Long matchId);
    Optional<PlayerMatchStatEntity> findByMatchIdAndPlayerId(Long matchId, Long playerId);

    @Query("""
      select s.player.id,
             coalesce(sum(s.minutes),0),
             coalesce(sum(s.goals),0),
             coalesce(sum(s.assists),0),
             coalesce(sum(s.yellowCards),0),
             coalesce(sum(s.redCards),0)
      from PlayerMatchStatEntity s
      where s.match.team.id = :teamId
      group by s.player.id
    """)
    List<Object[]> aggregateForTeam(Long teamId); // playerId, minutes, goals, assists, y, r
}

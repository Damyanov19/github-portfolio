package com.footballuniverse.management.dto;

import com.footballuniverse.management.enums.EventType;
import jakarta.validation.constraints.*;

public class EventDto {

    @NotNull
    private EventType type;

    // HTML5 datetime-local: "yyyy-MM-dd'T'HH:mm"
    @NotBlank
    private String dateTime; // ще го парснем ръчно към LocalDateTime

    @NotNull @Min(30) @Max(300)
    private Integer durationMin = 90;

    @NotBlank @Size(min = 2, max = 100)
    private String location;

    @Size(max = 2000)
    private String notes;

    // getters/setters...
    public EventType getType() { return type; }
    public void setType(EventType type) { this.type = type; }
    public String getDateTime() { return dateTime; }
    public void setDateTime(String dateTime) { this.dateTime = dateTime; }
    public Integer getDurationMin() { return durationMin; }
    public void setDurationMin(Integer durationMin) { this.durationMin = durationMin; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}

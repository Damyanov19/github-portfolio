package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.StatisticDto;

import java.util.List;

public interface StatisticService {

    StatisticDto create(StatisticDto dto);

    List<StatisticDto> findAll();

    StatisticDto findById(Long id);

    void delete(Long id);
}

package com.footballuniverse.management.web; // [ADD]

import com.footballuniverse.management.dto.MatchDto;
import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.EventType;
import com.footballuniverse.management.repository.EventRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.MatchService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/matches")
@PreAuthorize("hasAnyRole('ADMIN','COACH')") // [ADD]
public class MatchesController { // [ADD]

    private final MatchService matchService;
    private final UserRepository users;

    private final EventRepository events;
    // [ADD] Взимаме текущия потребител по Authentication



    public MatchesController(MatchService matchService, UserRepository users, EventRepository events) {
        this.matchService = matchService;
        this.users = users;
        this.events = events;
    }

    private UserEntity me(Authentication auth) {
        return users.findByUsername(auth.getName()).orElseThrow();
    }


    @GetMapping
    public String list(Authentication auth, Model model) {
        UserEntity me = users.findByUsername(auth.getName()).orElseThrow();
        Long teamId = me.getTeam().getId();

        // 1) Официални Match-ове от MatchService
        List<MatchDto> matches = matchService.getAllMatchesByTeam(teamId);
        model.addAttribute("matches", matches);

        // 2) [ADD] Fallback към EventEntity(type=MATCH), ако няма MatchEntity
        if (matches == null || matches.isEmpty()) {
            List<EventEntity> evMatches =
                    events.findAllByTeamIdAndTypeOrderByDateTimeDesc(teamId, EventType.MATCH);

            List<MatchDto> fallback = evMatches.stream().map(ev -> {
                MatchDto dto = new MatchDto();
                // ВНИМАНИЕ: това НЕ е MatchEntity ID, а Event ID — използвай за показване само.
                dto.setId(ev.getId());
                dto.setMatchDate(ev.getDateTime());
                dto.setOpponent(ev.getOpponent());           // ще е null ако нямаш opponent в EventEntity
                dto.setLocation(ev.getLocation());
                dto.setTeamId(teamId);
                return dto;
            }).collect(Collectors.toList());

            model.addAttribute("fallbackEvents", fallback);
        }

        return "matches/list";
    }

    // [ADD] към MatchesController
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String create(Authentication auth,
                         @RequestParam String opponent,                 // required в HTML
                         @RequestParam(required = false) String location,
                         @RequestParam String matchDate,                // идва от <input type="datetime-local">
                         RedirectAttributes ra) {
        var user = users.findByUsername(auth.getName()).orElseThrow();
        var teamId = user.getTeam().getId();

        // parse "yyyy-MM-dd'T'HH:mm"
        LocalDateTime dt;
        try {
            dt = LocalDateTime.parse(matchDate, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Невалидна дата/час.");
            return "redirect:/matches";
        }

        var dto = new MatchDto();
        dto.setTeamId(teamId);
        dto.setOpponent(opponent.trim());           // няма да е null → няма да гръмне БД
        dto.setLocation(location == null ? null : location.trim());
        dto.setMatchDate(dt);

        matchService.saveMatch(dto);
        ra.addFlashAttribute("success", "Мачът е добавен.");
        return "redirect:/matches";
    }

    // [ADD] към MatchesController
    @PostMapping("/{id}/delete")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String delete(@PathVariable Long id, Authentication auth, RedirectAttributes ra) {
        // по желание: провери дали мачът е на отбора на текущия потребител
        matchService.deleteMatch(id);
        ra.addFlashAttribute("success", "Мачът е изтрит.");
        return "redirect:/matches";
    }


}

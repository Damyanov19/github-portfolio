package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.UserRegistrationDto;
import com.footballuniverse.management.enums.AgeGroupsEnum;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.http.MediaType;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Controller
public class RegistrationController {

    private final UserService userService;
    private final TeamRepository teamRepository;

    public RegistrationController(UserService userService, TeamRepository teamRepository) {
        this.userService = userService;
        this.teamRepository = teamRepository;
    }

    @GetMapping("/register")
    public String showRegistration(Model model) {
        model.addAttribute("userRegistrationDto", new UserRegistrationDto());
        model.addAttribute("teams", teamRepository.findAll());
        model.addAttribute("roles", new UserRoleEnums[]{UserRoleEnums.COACH, UserRoleEnums.PLAYER});
        model.addAttribute("ageGroups", AgeGroupsEnum.values());
        return "register";
    }

    @PostMapping(value = "/register")
    public String processRegistration(@ModelAttribute("userRegistrationDto") UserRegistrationDto dto,
                                      Model model) {
        try {
            userService.registerUser(dto);

            String msg = URLEncoder.encode("Успешна регистрация", StandardCharsets.UTF_8);
            return "redirect:/login?msg=" + msg;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("teams", teamRepository.findAll());
            model.addAttribute("roles", new UserRoleEnums[]{UserRoleEnums.COACH, UserRoleEnums.PLAYER});
            model.addAttribute("ageGroups", AgeGroupsEnum.values());
            return "register";
        }
    }

}

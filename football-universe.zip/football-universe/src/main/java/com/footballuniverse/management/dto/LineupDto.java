package com.footballuniverse.management.dto; // [ADD]

import com.footballuniverse.management.enums.LineupRole;
import java.util.HashMap;
import java.util.Map;

public class LineupDto { // [ADD]
    private String name;
    private String notes;
    private Long captainId;                       // id на избрания капитан (трябва да е сред STARTER)
    private Map<Long, LineupRole> roles = new HashMap<>();     // playerId -> role
    private Map<Long, String> positions = new HashMap<>();     // playerId -> "ST"/"GK"/...

    // getters/setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public Long getCaptainId() { return captainId; }
    public void setCaptainId(Long captainId) { this.captainId = captainId; }
    public Map<Long, LineupRole> getRoles() { return roles; }
    public void setRoles(Map<Long, LineupRole> roles) { this.roles = roles; }
    public Map<Long, String> getPositions() { return positions; }
    public void setPositions(Map<Long, String> positions) { this.positions = positions; }
}

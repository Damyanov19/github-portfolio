package com.footballuniverse.management.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "matches")
public class MatchEntity extends BaseEntity{

    @Column(nullable = false)
    private LocalDateTime matchDate;

    @Column(nullable = false)
    private String opponent;

    @Column
    private String location;

    @Column
    private Integer teamGoals;

    @Column
    private Integer opponentGoals;

    @ManyToOne
    @JoinColumn(name = "team_id", nullable = false)
    private TeamEntity team;

    // Getters and Setters
}

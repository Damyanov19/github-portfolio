package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.StatisticDto;
import com.footballuniverse.management.entity.MatchEntity;
import com.footballuniverse.management.entity.PlayerEntity;
import com.footballuniverse.management.entity.StatisticEntity;
import org.springframework.stereotype.Component;

@Component
public interface StatisticMapper {

    public static StatisticDto toDto(StatisticEntity entity) {
        StatisticDto dto = new StatisticDto();
        dto.setId(entity.getId());
        dto.setPlayerId(entity.getPlayer().getId());
        dto.setMatchId(entity.getMatch().getId());
        dto.setGoals(entity.getGoals());
        dto.setAssists(entity.getAssists());
        dto.setYellowCards(entity.getYellowCards());
        dto.setRedCards(entity.getRedCards());
        dto.setMinutesPlayed(entity.getMinutesPlayed());
        dto.setSubstituted(entity.isSubstituted());
        return dto;
    }

    public static StatisticEntity toEntity(StatisticDto dto, MatchEntity match, PlayerEntity player) {
        StatisticEntity entity = new StatisticEntity();
        entity.setId(dto.getId());
        entity.setPlayer(player);
        entity.setMatch(match);
        entity.setGoals(dto.getGoals());
        entity.setAssists(dto.getAssists());
        entity.setYellowCards(dto.getYellowCards());
        entity.setRedCards(dto.getRedCards());
        entity.setMinutesPlayed(dto.getMinutesPlayed());
        entity.setSubstituted(dto.isSubstituted());
        return entity;
    }
}

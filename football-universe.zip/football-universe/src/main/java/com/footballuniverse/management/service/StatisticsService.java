package com.footballuniverse.management.service; // [ADD]

import com.footballuniverse.management.dto.PlayerStatSummaryDto;
import com.footballuniverse.management.entity.PlayerMatchStatEntity;

import java.util.List;
import java.util.Optional;

public interface StatisticsService { // [ADD]
    List<PlayerStatSummaryDto> getTeamPlayerSummaries(Long teamId);

    List<PlayerMatchStatEntity> getMatchStats(Long matchId);

    PlayerMatchStatEntity upsertMatchPlayerStat(Long matchId, Long playerId,
                                                Integer minutes, Integer goals, Integer assists,
                                                Integer yellow, Integer red,
                                                Boolean starter, Integer onMin, Integer offMin,
                                                String notes);

    void deleteMatchPlayerStat(Long id);

    void setPlayerFormScore(Long playerId, int max);
}

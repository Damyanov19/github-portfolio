package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.UserDto;
import com.footballuniverse.management.entity.user.UserEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper {

    public static UserDto toDto(UserEntity entity) {
        UserDto dto = new UserDto();
        dto.setId(entity.getId());
        dto.setUsername(entity.getUsername());
        dto.setEmail(entity.getEmail());
        dto.setRole(entity.getRole() != null ? entity.getRole().getRole() : null);
        dto.setTeam(entity.getTeam() != null ? entity.getTeam().getName() : null);
        dto.setApproved(entity.isApproved());
        return dto;
    }
}

package com.footballuniverse.management.entity;

import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity @Table(name = "messages")
public class MessageEntity extends BaseEntity {

    @ManyToOne(optional=false, fetch=FetchType.LAZY)
    @JoinColumn(name="team_id")
    private TeamEntity team;

    @ManyToOne(optional=false, fetch=FetchType.LAZY)
    @JoinColumn(name="sender_id")
    private UserEntity sender;

    @Column(nullable=false, length=120)
    private String title;

    @Column(nullable=false, columnDefinition="TEXT")
    private String body;

    @Enumerated(EnumType.STRING)
    @Column(nullable=false, length=16)
    private final TargetRole targetRole = TargetRole.ALL;

    @Column(nullable=false)
    private final LocalDateTime createdAt = LocalDateTime.now();



    public enum TargetRole { ALL, PLAYERS, COACHES }
}

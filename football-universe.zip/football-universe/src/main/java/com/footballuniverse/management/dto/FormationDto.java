package com.footballuniverse.management.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FormationDto {
    private Long id;
    private String name;
    private String description;
}

package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.MatchDto;
import com.footballuniverse.management.entity.MatchEntity;
import com.footballuniverse.management.entity.TeamEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface MatchMapper {

    public static MatchDto toDto(MatchEntity entity) {
        MatchDto dto = new MatchDto();
        dto.setId(entity.getId());
        dto.setMatchDate(entity.getMatchDate());
        dto.setOpponent(entity.getOpponent());
        dto.setLocation(entity.getLocation());
        dto.setTeamGoals(entity.getTeamGoals());
        dto.setOpponentGoals(entity.getOpponentGoals());
        dto.setTeamId(entity.getTeam().getId());
        return dto;
    }

    public static MatchEntity toEntity(MatchDto dto, TeamEntity team) {
        MatchEntity entity = new MatchEntity();
        entity.setId(dto.getId());
        entity.setMatchDate(dto.getMatchDate());
        entity.setOpponent(dto.getOpponent());
        entity.setLocation(dto.getLocation());
        entity.setTeamGoals(dto.getTeamGoals());
        entity.setOpponentGoals(dto.getOpponentGoals());
        entity.setTeam(team);
        return entity;
    }
}

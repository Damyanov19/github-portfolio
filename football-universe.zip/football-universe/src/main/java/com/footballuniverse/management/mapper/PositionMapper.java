package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.PositionDto;
import com.footballuniverse.management.entity.PositionEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PositionMapper {

    public static PositionEntity toEntity(PositionDto dto) {
        PositionEntity entity = new PositionEntity();
        entity.setId(dto.getId());
        entity.setName(dto.getName());
        return entity;
    }

    public static PositionDto toDto(PositionEntity entity) {
        PositionDto dto = new PositionDto();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        return dto;
    }
}

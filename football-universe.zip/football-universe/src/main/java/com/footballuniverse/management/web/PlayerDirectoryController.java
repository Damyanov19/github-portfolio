package com.footballuniverse.management.web; // [ADD]

import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Comparator;
import java.util.List;

@Controller
@RequestMapping("/team/players") // URL: /team/players
public class PlayerDirectoryController { // [ADD]

    private final UserRepository users;

    public PlayerDirectoryController(UserRepository users) {
        this.users = users;
    }

    private TeamEntity currentTeam(Authentication auth) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();
        return u.getTeam();
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String list(Authentication auth, Model model) {
        Long teamId = currentTeam(auth).getId();

        List<UserEntity> teamMembers = users.findAllByTeamIdOrderByUsernameAsc(teamId);


        teamMembers = teamMembers.stream()
                .sorted(Comparator
                        .comparing((UserEntity u) -> u.getRole() == null ? "" : u.getRole().getRole().name())
                        .thenComparing(u -> u.getPosition() == null ? "" : u.getPosition())
                        .thenComparing(UserEntity::getUsername))
                .toList();

        model.addAttribute("members", teamMembers);
        model.addAttribute("UserRoleEnums", UserRoleEnums.class);
        return "players/list"; // templates/players/list.html
    }
}

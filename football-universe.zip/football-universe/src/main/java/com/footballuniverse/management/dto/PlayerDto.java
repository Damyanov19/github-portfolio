package com.footballuniverse.management.dto;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlayerDto {

    private Long id;
    private String firstName;
    private String lastName;
    private String position;
    private int jerseyNumber;
    private LocalDate birthDate;
    private boolean active;
    private Long teamId;
    private Long userId; // optional

    // Getters & Setters
}

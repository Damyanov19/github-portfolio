package com.footballuniverse.management.init;

import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.RoleEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.repository.RoleRepository;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seed(UserRepository users,
                           TeamRepository teams,
                           RoleRepository roles,
                           PasswordEncoder enc) {
        return args -> {
            // 1) Роли
            for (UserRoleEnums r : List.of(UserRoleEnums.ADMIN, UserRoleEnums.COACH, UserRoleEnums.PLAYER)) {
                roles.findByRole(r).orElseGet(() -> {
                    RoleEntity re = new RoleEntity();
                    re.setRole(r);
                    return roles.save(re);
                });
            }

            boolean adminMissing =
                    users.findByUsername("YordanDamyanov19").isEmpty() ||
                            users.findByEmail("admin1@team.bg").isEmpty();

            if (adminMissing) {
                TeamEntity t = teams.findByName("Demo FC").orElseGet(() -> {
                    TeamEntity nt = new TeamEntity();
                    nt.setName("Demo FC");
                    nt.setCity("Sofia");
                    nt.setCountry("Bulgaria");
                    nt.setDescription("Seed team");
                    return teams.save(nt);
            });

                RoleEntity adminRole = roles.findByRole(UserRoleEnums.ADMIN).orElseThrow();

                UserEntity admin = new UserEntity();
                admin.setUsername("YordanDamyanov19");
                admin.setEmail("admin1@team.bg");
                admin.setPasswordHash(enc.encode("admin123")); // Argon2 bean
                admin.setRole(adminRole);
                admin.setTeam(t);
                admin.setApproved(true);
                users.save(admin);
            }
        };
    }
}

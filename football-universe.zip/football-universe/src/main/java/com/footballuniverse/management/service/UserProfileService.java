package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.UserProfileDto;

public interface UserProfileService {
    UserProfileDto getProfile(String username);

    void updateProfile(String username, UserProfileDto form);
}

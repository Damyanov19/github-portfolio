package com.footballuniverse.management.web;

import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.entity.AttendanceEntity;
import com.footballuniverse.management.enums.AttendanceStatusEnum;
import com.footballuniverse.management.repository.AttendanceRepository;
import com.footballuniverse.management.repository.EventRepository;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/attendance")
public class AttendanceController {

    private final EventRepository events;
    private final AttendanceRepository attendanceRepo;
    private final UserRepository users;

    public AttendanceController(EventRepository events,
                                AttendanceRepository attendanceRepo,
                                UserRepository users) {
        this.events = events;
        this.attendanceRepo = attendanceRepo;
        this.users = users;
    }

    private UserEntity me(Authentication auth) {
        return users.findByUsername(auth.getName()).orElseThrow();
    }
    private TeamEntity myTeam(Authentication auth) {
        return me(auth).getTeam();
    }
    private EventEntity ownedEvent(Long id, TeamEntity team) {
        return events.findByIdAndTeamId(id, team.getId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Събитието не е намерено за вашия отбор"));
    }

    @GetMapping
    public String root() { return "redirect:/events"; }


    @GetMapping("/manage/{eventId}")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String manage(@PathVariable Long eventId, Authentication auth, Model model) {
        var team = myTeam(auth);
        var ev = ownedEvent(eventId, team);


        var attendance = attendanceRepo.findAllByEventId(eventId);


        var allPlayers = users.findAllByTeamIdOrderByUsernameAsc(team.getId()).stream()
                .filter(u -> u.getRole() != null && u.getRole().getRole().name().equals("PLAYER"))
                .toList();


        var alreadyIds = attendance.stream().map(a -> a.getPlayer().getId()).collect(java.util.stream.Collectors.toSet());


        var availablePlayers = allPlayers.stream()
                .filter(u -> !alreadyIds.contains(u.getId()))
                .toList();


        model.addAttribute("event", ev);
        model.addAttribute("attendance", attendanceRepo.findAllByEventId(eventId));
        model.addAttribute("availablePlayers", availablePlayers);
        model.addAttribute("statusOptions", AttendanceStatusEnum.values());
        return "attendance/manage";
    }

    @PostMapping("/manage/{eventId}/add")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String addPlayer(@PathVariable Long eventId,
                            @RequestParam("playerId") Long playerId,
                            Authentication auth,
                            RedirectAttributes ra) {

        var team = myTeam(auth);
        var ev = ownedEvent(eventId, team);
        var player = users.findById(playerId).orElseThrow();

        if (!player.getTeam().getId().equals(team.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Играчът не е от вашия отбор");
        }

        var existing = attendanceRepo.findByEventIdAndPlayerId(eventId, playerId);
        if (existing.isPresent()) {
            ra.addFlashAttribute("error", "Този играч вече е в списъка за присъствие.");
            return "redirect:/attendance/manage/" + eventId;
        }

        var a = new AttendanceEntity();
        a.setEvent(ev);
        a.setPlayer(player);
        a.setStatus(AttendanceStatusEnum.YES); // стартов статус
        a.setReason(null);

        attendanceRepo.save(a);
        ra.addFlashAttribute("success", "Играчът е добавен към присъствието.");
        return "redirect:/attendance/manage/" + eventId;
    }


    @PostMapping("/manage/{eventId}/player/{playerId}")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String setForPlayer(@PathVariable Long eventId,
                               @PathVariable Long playerId,
                               @RequestParam String status,
                               @RequestParam(required = false) String reason,
                               Authentication auth) {
        var ev = ownedEvent(eventId, myTeam(auth));
        var player = users.findById(playerId).orElseThrow();
        if (!player.getTeam().getId().equals(ev.getTeam().getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Играчът не е от вашия отбор");
        }
        var a = attendanceRepo.findByEventIdAndPlayerId(eventId, playerId)
                .orElseGet(() -> { var na = new AttendanceEntity(); na.setEvent(ev); na.setPlayer(player); na.setStatus(AttendanceStatusEnum.UNDECIDED); return na; });
        a.setStatus(AttendanceStatusEnum.valueOf(status));
        a.setReason(reason);
        attendanceRepo.save(a);
        return "redirect:/attendance/manage/" + eventId;
    }


    @GetMapping("/manage/{eventId}/rsvp")
    @PreAuthorize("hasAnyRole('PLAYER','COACH','ADMIN')")
    public String rsvpForm(@PathVariable Long eventId,
                           @RequestParam(required = false) String status,
                           Authentication auth,
                           Model model) {
        var ev = ownedEvent(eventId, me(auth).getTeam());
        if (!"NO".equals(status)) {
            return "redirect:/events";
        }
        model.addAttribute("event", ev);
        return "attendance/rsvp_no";
    }

    @PostMapping("/manage/{eventId}/rsvp")
    @PreAuthorize("hasRole('PLAYER')")
    public String rsvp(@PathVariable Long eventId,
                       @RequestParam String status,
                       @RequestParam(required = false) String reason,
                       Authentication auth,
                       RedirectAttributes ra) {

        var user = me(auth);
        var ev = ownedEvent(eventId, user.getTeam());


        String s = status == null ? "" : status.trim().toUpperCase();
        if (!s.equals("YES") && !s.equals("NO")) {
            ra.addFlashAttribute("error", "Невалиден отговор. Разрешени са само YES или NO.");
            return "redirect:/events";
        }


        String finalReason = null;
        if (s.equals("NO")) {
            if (reason == null || reason.trim().isEmpty()) {
                ra.addFlashAttribute("error", "Моля, въведи причина при отказ.");
                return "redirect:/attendance/manage/" + eventId + "/rsvp?status=NO";
            }
            finalReason = reason.trim();
        }

        var attendance = attendanceRepo.findByEventIdAndPlayerId(eventId, user.getId())
                .orElseGet(() -> {
                    var a = new AttendanceEntity();
                    a.setEvent(ev);
                    a.setPlayer(user);
                    return a;
                });


        attendance.setStatus(AttendanceStatusEnum.valueOf(s));
        attendance.setReason(finalReason);

        attendanceRepo.save(attendance);

        ra.addFlashAttribute("success", "Отговорът е запазеня.");
        return "redirect:/events";
    }



}

package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.PlayerStatSummaryDto;              // [ADD]
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.MatchRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.StatisticsService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Comparator;
import java.util.Map;                                                          // [ADD]
import java.util.function.Function;                                           // [ADD]
import java.util.stream.Collectors;                                           // [ADD]

@Controller
@RequestMapping("/matches/{matchId}/report")
public class MatchReportController {

    private final MatchRepository matches;
    private final UserRepository users;
    private final StatisticsService stats;

    public MatchReportController(MatchRepository matches,
                                 UserRepository users,
                                 StatisticsService stats) {
        this.matches = matches;
        this.users = users;
        this.stats = stats;
    }

    private TeamEntity myTeam(Authentication auth) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();
        return u.getTeam();
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String form(@PathVariable Long matchId, Authentication auth, Model model) {
        var match = matches.findById(matchId).orElseThrow();
        var team = myTeam(auth);
        if (!match.getTeam().getId().equals(team.getId())) {
            return "redirect:/matches";
        }

        var players = users.findAllByTeamIdOrderByUsernameAsc(team.getId()).stream()
                .filter(u -> u.getRole() != null && u.getRole().getRole().name().equals("PLAYER"))
                .sorted(Comparator.comparing(UserEntity::getUsername))
                .toList();

        var existingStats = stats.getMatchStats(matchId);

        // [ADD] играчи, които още НЯМАТ ред в статистиката → за падащото меню „Добави“
        var already = existingStats.stream().map(s -> s.getPlayer().getId()).collect(Collectors.toSet());
        var availablePlayers = players.stream().filter(p -> !already.contains(p.getId())).toList();


        Map<Long, PlayerStatSummaryDto> summaryByPlayerId =
                stats.getTeamPlayerSummaries(team.getId()).stream()
                        .collect(Collectors.toMap(PlayerStatSummaryDto::getPlayerId, Function.identity()));

        model.addAttribute("match", match);
        model.addAttribute("players", players);
        model.addAttribute("availablePlayers", availablePlayers);             // [ADD]
        model.addAttribute("stats", existingStats);
        model.addAttribute("summaryByPlayerId", summaryByPlayerId);           // [ADD]
        return "matches/report";
    }

    @ModelAttribute("currentTeamName")
    public String currentTeamName(org.springframework.security.core.Authentication auth) {
        if (auth == null) return null;
        return users.findByUsername(auth.getName())
                .map(u -> u.getTeam() != null ? u.getTeam().getName() : null)
                .orElse(null);
    }

    @PostMapping("/score")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String saveScore(@PathVariable Long matchId,
                            @RequestParam Integer teamGoals,
                            @RequestParam Integer opponentGoals,
                            RedirectAttributes ra) {
        var m = matches.findById(matchId).orElseThrow();
        m.setTeamGoals(teamGoals);
        m.setOpponentGoals(opponentGoals);
        matches.save(m);
        ra.addFlashAttribute("success", "Резултатът е записан.");
        return "redirect:/matches/" + matchId + "/report";
    }

    @PostMapping("/player")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String savePlayer(@PathVariable Long matchId,
                             @RequestParam Long playerId,
                             @RequestParam(required = false) Integer minutes,
                             @RequestParam(required = false) Integer goals,
                             @RequestParam(required = false) Integer assists,
                             @RequestParam(required = false) Integer yellow,
                             @RequestParam(required = false) Integer red,
                             @RequestParam(required = false) Boolean starter,
                             @RequestParam(required = false) Integer cameOnMinute,
                             @RequestParam(required = false) Integer wentOffMinute,
                             @RequestParam(required = false) String notes,
                             RedirectAttributes ra) {
        stats.upsertMatchPlayerStat(matchId, playerId, minutes, goals, assists, yellow, red,
                starter, cameOnMinute, wentOffMinute, notes);
        ra.addFlashAttribute("success", "Статистиката за играча е записана.");
        return "redirect:/matches/" + matchId + "/report";
    }

    // [ADD] Изтриване на ред от статистиката за мач
    @PostMapping("/player/{statId}/delete")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String deletePlayerRow(@PathVariable Long matchId,
                                  @PathVariable Long statId,
                                  RedirectAttributes ra) {
        stats.deleteMatchPlayerStat(statId);
        ra.addFlashAttribute("success", "Редът е изтрит.");
        return "redirect:/matches/" + matchId + "/report";
    }
}

package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.TrainingDto;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.TrainingEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.TrainingRepository;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@Controller
@RequestMapping("/trainings")
public class TrainingController {

    private final TrainingRepository trainingRepo;
    private final UserRepository userRepo;

    public TrainingController(TrainingRepository trainingRepo, UserRepository userRepo) {
        this.trainingRepo = trainingRepo;
        this.userRepo = userRepo;
    }

    private TeamEntity currentTeam(Authentication auth) {
        UserEntity u = userRepo.findByUsername(auth.getName()).orElseThrow();
        return u.getTeam();
    }

    @GetMapping
    public String list(Authentication auth, Model model) {
        Long teamId = currentTeam(auth).getId();
        model.addAttribute("trainings",
                trainingRepo.findAllByTeamIdOrderByDateTimeDesc(teamId));
        return "trainings/list";
    }

    @GetMapping("/new")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String newForm(Model model) {
        model.addAttribute("form", new TrainingDto());
        return "trainings/form";
    }

    /** ВАЖНО: без път тук -> POST /trainings (не /trainings/trainings) */
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String create(@ModelAttribute("form") TrainingDto form, Authentication auth) {
        TeamEntity team = currentTeam(auth);

        TrainingEntity t = new TrainingEntity();
        t.setTeam(team);                                // <— ЗАДЪЛЖИТЕЛНО
        t.setDateTime(form.getTrainingDateTime());      // dto -> entity
        t.setLocation(form.getLocation());
//        t.setTeam(currentTeam(auth));;

        trainingRepo.save(t);
        System.out.println("SAVED TRAINING ID=" + t.getId());
        return "redirect:/trainings";
    }



    @GetMapping("/{id}/edit")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String editForm(@PathVariable Long id, Authentication auth, Model model) {
        TrainingEntity t = trainingRepo.findById(id).orElseThrow();
        if (!t.getTeam().getId().equals(currentTeam(auth).getId()))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Нямате права");

        TrainingDto form = new TrainingDto();
        form.setId(t.getId());
        form.setTrainingDateTime(t.getDateTime());
        form.setLocation(t.getLocation());
        // попълни и други полета, ако имаш

        model.addAttribute("form", form);
        return "trainings/form";
    }

    @PostMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String update(@PathVariable Long id, @ModelAttribute("form") TrainingDto form, Authentication auth) {
        TrainingEntity t = trainingRepo.findById(id).orElseThrow();
        if (!t.getTeam().getId().equals(currentTeam(auth).getId()))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Нямате права");

        t.setDateTime(form.getTrainingDateTime());
        t.setLocation(form.getLocation());
        // t.setDurationMinutes(form.getDurationMinutes());
        // t.setNotes(form.getFocus());

        trainingRepo.save(t);
        return "redirect:/trainings";
    }

    @PostMapping("/{id}/delete")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String delete(@PathVariable Long id, Authentication auth) {
        TrainingEntity t = trainingRepo.findById(id).orElseThrow();
        if (!t.getTeam().getId().equals(currentTeam(auth).getId()))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Нямате права");

        trainingRepo.delete(t);
        return "redirect:/trainings";
    }
}

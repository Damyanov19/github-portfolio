package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.PlayerDto;
import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.entity.user.UserEntity;

import java.util.List;
import java.util.Optional;

public interface PlayerService {
    static void assignPosition(UserEntity u, String position) {
    }

    Optional<UserEntity> findById(Long id);
    UserProfileDto toUserProfileDto(UserEntity u);
    void applyProfile(UserEntity u, UserProfileDto dto);

    PlayerDto createPlayer(PlayerDto dto);
    PlayerDto updatePlayer(Long id, PlayerDto dto);
    void deletePlayer(Long id);
    PlayerDto getById(Long id);
    List<PlayerDto> getAll();
    List<PlayerDto> getByTeamId(Long teamId);
}

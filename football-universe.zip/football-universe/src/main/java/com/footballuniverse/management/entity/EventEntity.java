package com.footballuniverse.management.entity;

import com.footballuniverse.management.enums.EventType;
import jakarta.persistence.*;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "events")
public class EventEntity extends BaseEntity {


    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false, length = 16)
    private EventType type; // TRAINING или MATCH

    @NotNull @FutureOrPresent
    @Column(nullable = false)
    private LocalDateTime dateTime;

    @NotNull
    @Column(nullable = false)
    private Integer durationMin = 90; // по подразбиране

    @NotBlank
    @Column(nullable = false)
    private String location;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id", nullable = false)
    private TeamEntity team;

    @Column(name = "home_goals")
    private Integer homeGoals = 0;

    @Column(name = "away_goals")
    private Integer awayGoals = 0;

    @Column(length = 120)
    private String opponent;

    public EventType getType() { return type; }
    public void setType(EventType type) { this.type = type; }
    public LocalDateTime getDateTime() { return dateTime; }
    public void setDateTime(LocalDateTime dateTime) { this.dateTime = dateTime; }
    public Integer getDurationMin() { return durationMin; }
    public void setDurationMin(Integer durationMin) { this.durationMin = durationMin; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public TeamEntity getTeam() { return team; }
    public void setTeam(TeamEntity team) { this.team = team; }

}

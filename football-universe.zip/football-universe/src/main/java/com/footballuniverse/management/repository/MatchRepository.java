package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.MatchEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MatchRepository extends JpaRepository<MatchEntity, Long> {
    List<MatchEntity> findAllByTeamId(Long teamId);

    Optional<MatchEntity> findFirstByTeamIdAndMatchDate(Long teamId, LocalDateTime matchDate);

    // [ADD] MatchRepository
    Optional<MatchEntity> findById(Long id); // обикновено го има от JpaRepository
    boolean existsById(Long id);             // също
    MatchEntity findTopByTeamIdAndMatchDateOrderByIdDesc(Long teamId, LocalDateTime matchDate); // [ADD]

}

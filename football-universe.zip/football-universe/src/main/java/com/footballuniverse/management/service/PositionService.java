package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.PositionDto;

import java.util.List;

public interface PositionService {
    PositionDto create(PositionDto dto);
    List<PositionDto> findAll();
    PositionDto findById(Long id);
    void delete(Long id);
}

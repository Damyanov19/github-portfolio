package com.footballuniverse.management.entity;

import com.footballuniverse.management.entity.user.UserEntity;
import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;


@Entity
@Table(name = "reminders")
public class ReminderEntity extends BaseEntity {

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id", nullable = false)
    private TeamEntity team;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by_id")
    private UserEntity createdBy;

    @Column(nullable = false, length = 120)
    private String title;
    @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
    @Column(name = "due_at", nullable = false)
    private LocalDateTime dueAt;

    @Column(columnDefinition = "TEXT")
    private String note;

    @Column(nullable = false)
    private boolean done = false;

    // getters/setters
    public TeamEntity getTeam() { return team; }
    public void setTeam(TeamEntity team) { this.team = team; }
    public UserEntity getCreatedBy() { return createdBy; }
    public void setCreatedBy(UserEntity createdBy) { this.createdBy = createdBy; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public LocalDateTime getDueAt() { return dueAt; }
    public void setDueAt(LocalDateTime dueAt) { this.dueAt = dueAt; }
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
    public boolean isDone() { return done; }
    public void setDone(boolean done) { this.done = done; }
}

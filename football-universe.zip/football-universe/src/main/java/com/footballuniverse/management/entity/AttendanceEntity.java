package com.footballuniverse.management.entity;

import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.AttendanceStatusEnum;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(
        name = "attendance",
        uniqueConstraints = @UniqueConstraint(
                name = "uk_attendance_training_player",
                columnNames = {"event_id", "player_id"}
        ))
public class AttendanceEntity extends BaseEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "event_id", nullable = false)
    private EventEntity event;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "player_id", nullable = false)
    private UserEntity player;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    private AttendanceStatusEnum status = AttendanceStatusEnum.UNDECIDED;
    @Column(length = 255)
    private String reason; // по желание от играча/треньора

    // getters/setters
    public EventEntity getEvent() { return event; }
    public void setEvent(EventEntity event) { this.event = event; }


    public UserEntity getPlayer() { return player; }
    public void setPlayer(UserEntity player) { this.player = player; }

    public AttendanceStatusEnum getStatus() { return status; }
    public void setStatus(AttendanceStatusEnum status) { this.status = status; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

}



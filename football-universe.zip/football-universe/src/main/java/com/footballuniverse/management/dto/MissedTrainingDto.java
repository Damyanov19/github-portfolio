package com.footballuniverse.management.dto;

import lombok.Data;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class MissedTrainingDto {

    private Long id;
    private Long playerId;
    private String playerName;
    private String reason;
    private String location;
    private LocalDate date;
}

package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.MatchDto;
import com.footballuniverse.management.entity.MatchEntity;
import com.footballuniverse.management.entity.TeamEntity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MatchService {
    List<MatchDto> getAllMatchesByTeam(Long teamId);
    MatchDto getMatchById(Long id);
    void saveMatch(MatchDto matchDto);
    void deleteMatch(Long id);

    Optional<MatchDto> findFirstByTeamAndMatchDate(Long teamId, LocalDateTime matchDate);

}

package com.footballuniverse.management.web;

import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.AdminUserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/users")
@PreAuthorize("hasRole('ADMIN')")
public class AdminUsersController {
    private final AdminUserService adminUserService;
    private final UserRepository users;
    private final TeamRepository teams;

    public AdminUsersController(AdminUserService adminUserService, UserRepository users, TeamRepository teams) {
        this.adminUserService = adminUserService;
        this.users = users;
        this.teams = teams;
    }


    private TeamEntity currentTeam(Authentication auth) {
        return users.findByUsername(auth.getName()).orElseThrow().getTeam();
    }

    @GetMapping
    public String list(Authentication auth, Model model) {
        Long teamId = currentTeam(auth).getId();
        model.addAttribute("players", users.findAllByTeam_Id(teamId));
        model.addAttribute("team", currentTeam(auth));
        model.addAttribute("roles", new UserRoleEnums[]{UserRoleEnums.COACH, UserRoleEnums.PLAYER});
        return "admin/users/list";
    }

    @PostMapping("/add-existing")
    public String addExisting(@RequestParam Long userId,
                              @RequestParam UserRoleEnums role,
                              Authentication auth) {
        adminUserService.addExistingUserToTeam(userId, currentTeam(auth).getId(), role);
        return "redirect:/admin/users";
    }

    @PostMapping("/create")
    public String create(@RequestParam String username,
                         @RequestParam String email,
                         @RequestParam String password,
                         @RequestParam UserRoleEnums role,
                         Authentication auth) {
        adminUserService.createUserInTeam(username, email, password, currentTeam(auth).getId(), role);
        return "redirect:/admin/users";
    }

    @PostMapping("/{id}/role")
    public String changeRole(@PathVariable Long id, @RequestParam UserRoleEnums role) {
        adminUserService.changeUserRole(id, role);
        return "redirect:/admin/users";
    }

    @PostMapping("/{id}/remove")
    public String remove(@PathVariable Long id) {
        adminUserService.removeUserFromTeam(id);
        return "redirect:/admin/users";
    }
}


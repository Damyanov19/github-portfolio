package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.FormationDto;
import com.footballuniverse.management.entity.FormationEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface FormationMapper {

    public static FormationDto toDto(FormationEntity formation) {
        return FormationDto.builder()
                .id(formation.getId())
                .name(formation.getName())
                .description(formation.getDescription())
                .build();
    }

    public static FormationEntity toEntity(FormationDto dto) {
        return FormationEntity.builder()
                .name(dto.getName())
                .description(dto.getDescription())
                .build();
    }
}

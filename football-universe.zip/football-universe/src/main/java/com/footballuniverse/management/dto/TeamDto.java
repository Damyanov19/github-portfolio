package com.footballuniverse.management.dto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TeamDto {

    private Long id;
    private String name;
    private String description;
    private String country;
    private String city;


}

package com.footballuniverse.management.web;

import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.EventRepository;
import com.footballuniverse.management.repository.ReminderRepository;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/calendar")
public class CalendarController {

    private final UserRepository users;
    private final ReminderRepository reminders;

    private final EventRepository events;


    public CalendarController(UserRepository users, ReminderRepository reminders, EventRepository events) {
        this.users = users;
        this.reminders = reminders;
        this.events = events;
    }

    private TeamEntity currentTeam(Authentication auth) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();
        return u.getTeam();
    }


    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','COACH','PLAYER')")
    public String index(Authentication auth, Model model) {
        Long teamId = currentTeam(auth).getId();

        LocalDate first = LocalDate.now().withDayOfMonth(1);
        LocalDate last  = first.plusMonths(1).minusDays(1);

        var remindersInMonth = reminders.findAllByTeamIdAndDueAtBetweenOrderByDueAtAsc(
                teamId, first.atStartOfDay(), last.atTime(23,59,59));

        var eventsInMonth = events.findAllByTeamIdAndDateTimeBetweenOrderByDateTimeAsc(
                teamId, first.atStartOfDay(), last.atTime(23,59,59));

        Map<LocalDate, List<EventEntity>> eventsByDay = eventsInMonth.stream()
                .collect(Collectors.groupingBy(e -> e.getDateTime().toLocalDate(), Collectors.toList()));


        model.addAttribute("monthStart", first);
        model.addAttribute("monthEnd", last);
        model.addAttribute("reminders", remindersInMonth);
        model.addAttribute("events", eventsInMonth);
        model.addAttribute("eventsByDay", eventsByDay);



        return "calendar/index";
    }
}

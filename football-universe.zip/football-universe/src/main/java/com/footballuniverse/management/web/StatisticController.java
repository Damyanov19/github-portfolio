package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.StatisticDto;
import com.footballuniverse.management.service.StatisticService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/statistics")
public class StatisticController {

    private final StatisticService statisticService;

    public StatisticController(StatisticService statisticService) {
        this.statisticService = statisticService;
    }

    @GetMapping
    public String showAllStatistics(Model model) {
        model.addAttribute("statistics", statisticService.findAll());
        return "statistics/statistics-list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("statistic", new StatisticDto());
        return "statistics/statistics-form";
    }

    @PostMapping("/add")
    public String addStatistic(@ModelAttribute("statistic") StatisticDto dto) {
        statisticService.create(dto);
        return "redirect:/statistics";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        statisticService.delete(id);
        return "redirect:/statistics";
    }
}

package com.footballuniverse.management.mapper;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface LineupPlayerPositionMapper {

    // Ако позицията е просто текст – остави така:
    default String toDb(String pos) {
        return pos == null ? null : pos.trim();
    }

    default String fromDb(String pos) {
        return pos;
    }

    // Ако имаш enum Position – можеш да добавиш:
    // default String toDb(Position p) { return p == null ? null : p.name(); }
    // default Position fromDb(String s) { return s == null ? null : Position.valueOf(s); }
}

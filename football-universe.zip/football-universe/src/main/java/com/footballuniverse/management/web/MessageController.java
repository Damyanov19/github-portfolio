package com.footballuniverse.management.web;

import com.footballuniverse.management.entity.MessageEntity;
import com.footballuniverse.management.entity.MessageEntity.TargetRole;
import com.footballuniverse.management.entity.TeamMessageCommentEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.repository.MessageRepository;
import com.footballuniverse.management.repository.TeamMessageCommentRepository;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/team/messages")
public class MessageController {

    private final MessageRepository messages;
    private final TeamMessageCommentRepository comments;
    private final UserRepository users;

    public MessageController(MessageRepository messages, TeamMessageCommentRepository comments, UserRepository users) {
        this.messages = messages;
        this.comments = comments;
        this.users = users;
    }

    private UserEntity me(Authentication auth) {
        return users.findByUsername(auth.getName()).orElseThrow();
    }

    @GetMapping
    public String list(Authentication auth, Model model) {
        var u = me(auth);
        var teamId = u.getTeam().getId();

        var role = u.getRole().getRole();
        var all = messages.findAllByTeamIdOrderByCreatedAtDesc(teamId).stream()
                .filter(m ->
                        m.getTargetRole() == TargetRole.ALL ||
                                (role == UserRoleEnums.PLAYER  && m.getTargetRole() == TargetRole.PLAYERS) ||
                                ((role == UserRoleEnums.COACH || role == UserRoleEnums.ADMIN) && m.getTargetRole() == TargetRole.COACHES)
                )
                .toList();

        model.addAttribute("messages", all);
        return "messages/list";
    }


    @GetMapping("/new")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String newForm(Model model) {
        model.addAttribute("message", new MessageEntity());
        model.addAttribute("targetRoles", TargetRole.values());
        return "messages/form";
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String create(@ModelAttribute("message") MessageEntity form, Authentication auth) {
        var u = me(auth);
        form.setTeam(u.getTeam());
        form.setSender(u);
        messages.save(form);
        return "redirect:/team/messages";
    }

    @GetMapping("/view/{id:\\d+}")
    @PreAuthorize("hasAnyRole('ADMIN','COACH','PLAYER')")
    public String viewMessage(@PathVariable Long id, Authentication auth, Model model) {
        var u = me(auth);
        var msg = messages.findById(id).orElseThrow();

        // (по желание) защита: съобщението трябва да е от същия отбор
        if (!msg.getTeam().getId().equals(u.getTeam().getId())) {
            return "redirect:/team/messages?error=forbidden";
        }

        model.addAttribute("message", msg);
        model.addAttribute("comments", comments.findByMessageIdOrderByCreatedAtAsc(id));
        return "messages/view";
    }



    @PostMapping("/{id:\\d+}/comments")
    @PreAuthorize("hasAnyRole('ADMIN','COACH','PLAYER')")
    public String addComment(@PathVariable Long id,
                             @RequestParam("content") String content,
                             Authentication auth) {
        if (!StringUtils.hasText(content)) {
            return "redirect:/team/messages/view/" + id + "?error=empty";
        }

        var msg = messages.findById(id).orElseThrow();
        var u = me(auth);


        if (!msg.getTeam().getId().equals(u.getTeam().getId())) {
            return "redirect:/team/messages?error=forbidden";
        }

        var c = new TeamMessageCommentEntity();
        c.setMessage(msg);
        c.setAuthor(u);
        c.setContent(content.trim());
        comments.save(c);

        return "redirect:/team/messages/view/" + id + "?success=1";
    }
}

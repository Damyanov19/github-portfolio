package com.footballuniverse.management.service.impl; // [ADD]

import com.footballuniverse.management.dto.PlayerStatSummaryDto;
import com.footballuniverse.management.entity.AttendanceEntity;
import com.footballuniverse.management.entity.MatchEntity;
import com.footballuniverse.management.entity.PlayerMatchStatEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.AttendanceRepository;
import com.footballuniverse.management.repository.MatchRepository;
import com.footballuniverse.management.repository.PlayerMatchStatRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.StatisticsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class StatisticsServiceImpl implements StatisticsService { // [ADD]

    private final PlayerMatchStatRepository statsRepo;
    private final AttendanceRepository attendanceRepo;
    private final MatchRepository matchRepo;
    private final UserRepository userRepo;

    public StatisticsServiceImpl(PlayerMatchStatRepository statsRepo,
                                 AttendanceRepository attendanceRepo,
                                 MatchRepository matchRepo,
                                 UserRepository userRepo) {
        this.statsRepo = statsRepo;
        this.attendanceRepo = attendanceRepo;
        this.matchRepo = matchRepo;
        this.userRepo = userRepo;
    }

    @Override
    public List<PlayerMatchStatEntity> getMatchStats(Long matchId) {
        return statsRepo.findAllByMatchId(matchId);
    }

    @Override
    @Transactional
    public PlayerMatchStatEntity upsertMatchPlayerStat(Long matchId, Long playerId,
                                                       Integer minutes, Integer goals, Integer assists,
                                                       Integer yellow, Integer red,
                                                       Boolean starter, Integer onMin, Integer offMin,
                                                       String notes) {

        var match = matchRepo.findById(matchId).orElseThrow();
        var player = userRepo.findById(playerId).orElseThrow();

        var stat = statsRepo.findByMatchIdAndPlayerId(matchId, playerId)
                .orElseGet(() -> {
                    var s = new PlayerMatchStatEntity();
                    s.setMatch(match);
                    s.setPlayer(player);
                    return s;
                });

        stat.setMinutes(Optional.ofNullable(minutes).orElse(0));
        stat.setGoals(Optional.ofNullable(goals).orElse(0));
        stat.setAssists(Optional.ofNullable(assists).orElse(0));
        stat.setYellowCards(Optional.ofNullable(yellow).orElse(0));
        stat.setRedCards(Optional.ofNullable(red).orElse(0));
        stat.setStarter(Optional.ofNullable(starter).orElse(Boolean.FALSE));
        stat.setCameOnMinute(onMin);
        stat.setWentOffMinute(offMin);
        stat.setNotes(notes);

        return statsRepo.save(stat);
    }

    @Override
    public void deleteMatchPlayerStat(Long id) {
        statsRepo.deleteById(id);
    }

    @Override
    public void setPlayerFormScore(Long playerId, int max) {

    }

    @Override
    public List<PlayerStatSummaryDto> getTeamPlayerSummaries(Long teamId) {
        var rows = statsRepo.aggregateForTeam(teamId);

        Map<Long,Integer> absences = new HashMap<>();
        var allAttendance = attendanceRepo.findAll();
        for (AttendanceEntity a : allAttendance) {
            if (a.getEvent() != null && a.getEvent().getTeam() != null
                    && Objects.equals(a.getEvent().getTeam().getId(), teamId)
                    && a.getStatus() != null && "NO".equals(a.getStatus().name())) {
                absences.merge(a.getPlayer().getId(), 1, Integer::sum);
            }
        }

        Map<Long,String> names = new HashMap<>();
        userRepo.findAll().forEach(u -> names.put(u.getId(), u.getUsername()));

        List<PlayerStatSummaryDto> list = new ArrayList<>();
        for (Object[] r : rows) {
            Long pid = (Long) r[0];
            int minutes = ((Number) r[1]).intValue();
            int goals = ((Number) r[2]).intValue();
            int assists = ((Number) r[3]).intValue();
            int y = ((Number) r[4]).intValue();
            int red = ((Number) r[5]).intValue();
            int miss = absences.getOrDefault(pid, 0);

            double mins = Math.max(1, minutes);
            double matches = Math.max(1.0, mins / 90.0);
            double g90 = goals   * 90.0 / mins;
            double a90 = assists * 90.0 / mins;
            double availability = Math.min(1.0, mins / (90.0 * 5));
            double disciplinePenalty = (y * 0.30 + red * 1.50) / matches;

            double raw = 3.0 + 3.0*g90 + 2.0*a90 + 3.0*availability - disciplinePenalty;
            int form = (int)Math.round(Math.max(0.0, Math.min(10.0, raw)));

            var dto = new PlayerStatSummaryDto();
            dto.setPlayerId(pid);
            dto.setUsername(names.getOrDefault(pid, "user#" + pid));
            dto.setMinutes(minutes);
            dto.setGoals(goals);
            dto.setAssists(assists);
            dto.setYellow(y);
            dto.setRed(red);
            dto.setAbsences(miss);
            dto.setFormScore(form);

            list.add(dto);
        }
        return list;
    }
}

package com.footballuniverse.management.entity; // [ADD]

import com.footballuniverse.management.entity.user.UserEntity;
import jakarta.persistence.*;
import lombok.Getter; import lombok.Setter;

@Getter @Setter
@Entity
@Table(name = "player_match_stats",
        uniqueConstraints = @UniqueConstraint(columnNames = {"match_id","player_id"}))
public class PlayerMatchStatEntity extends BaseEntity { // [ADD]

    @ManyToOne(optional = false)
    @JoinColumn(name = "match_id")
    private MatchEntity match;

    @ManyToOne(optional = false)
    @JoinColumn(name = "player_id")
    private UserEntity player;

    @Column(nullable = false)
    private Integer minutes = 0;

    @Column(nullable = false)
    private Integer goals = 0;

    @Column(nullable = false)
    private Integer assists = 0;

    @Column(nullable = false)
    private Integer yellowCards = 0;

    @Column(nullable = false)
    private Integer redCards = 0;

    // за смени / титуляр
    @Column private Boolean starter = Boolean.FALSE;
    @Column private Integer cameOnMinute;     // ако е резерва
    @Column private Integer wentOffMinute;    // ако е сменен

    // свободен текст
    @Column(length = 1000) private String notes;
}

package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.dto.PositionDto;
import com.footballuniverse.management.entity.PositionEntity;
import com.footballuniverse.management.mapper.PositionMapper;
import com.footballuniverse.management.repository.PositionRepository;
import com.footballuniverse.management.service.PositionService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PositionServiceImpl implements PositionService {

    private final PositionRepository positionRepository;

    public PositionServiceImpl(PositionRepository positionRepository) {
        this.positionRepository = positionRepository;
    }

    @Override
    public PositionDto create(PositionDto dto) {
        PositionEntity entity = PositionMapper.toEntity(dto);
        return PositionMapper.toDto(positionRepository.save(entity));
    }

    @Override
    public List<PositionDto> findAll() {
        return positionRepository.findAll().stream()
                .map(PositionMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public PositionDto findById(Long id) {
        return positionRepository.findById(id)
                .map(PositionMapper::toDto)
                .orElseThrow();
    }

    @Override
    public void delete(Long id) {
        positionRepository.deleteById(id);
    }
}

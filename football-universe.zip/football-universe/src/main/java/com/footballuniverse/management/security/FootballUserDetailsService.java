package com.footballuniverse.management.security;

import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class FootballUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public FootballUserDetailsService(UserRepository userRepo) {
        this.userRepository = userRepo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) {
        UserEntity u = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("No user: " + username));

        if (u.getRole() == null || u.getRole().getRole() == null)
            throw new IllegalStateException("Потребителят няма роля.");

        String roleName = "ROLE_" + u.getRole().getRole().name();
        GrantedAuthority auth = new SimpleGrantedAuthority(roleName);

        String encoded = u.getPasswordHash();

        return User.builder()
                .username(u.getUsername())
                .password(encoded == null ? "" : encoded)
                .authorities(List.of(auth))
                .accountExpired(false)
                .accountLocked(false)
                .credentialsExpired(false)
                .disabled(!u.isApproved())
                .build();

    }
}



package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.mapper.RoleMapper;
import com.footballuniverse.management.dto.RoleDto;
import com.footballuniverse.management.repository.RoleRepository;
import com.footballuniverse.management.service.RoleService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    private final RoleRepository roleRepository;

    public RoleServiceImpl(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public List<RoleDto> getAllRoles() {
        return roleRepository.findAll().stream()
                .map(RoleMapper::toDto)
                .toList();
    }

    @Override
    public RoleDto getRoleByName(String name) {
        return roleRepository.findByRole(UserRoleEnums.valueOf(name))
                .map(RoleMapper::toDto)
                .orElseThrow();
    }
}

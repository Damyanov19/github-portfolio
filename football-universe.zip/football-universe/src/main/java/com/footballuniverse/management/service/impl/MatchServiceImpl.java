package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.mapper.MatchMapper;
import com.footballuniverse.management.dto.MatchDto;
import com.footballuniverse.management.entity.MatchEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.repository.MatchRepository;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.service.MatchService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class MatchServiceImpl implements MatchService {

    private final MatchRepository matchRepository;
    private final TeamRepository teamRepository;

    public MatchServiceImpl(MatchRepository matchRepository, TeamRepository teamRepository) {
        this.matchRepository = matchRepository;
        this.teamRepository = teamRepository;
    }

    @Override
    public List<MatchDto> getAllMatchesByTeam(Long teamId) {
        return matchRepository.findAllByTeamId(teamId).stream()
                .map(MatchMapper::toDto)
                .toList();
    }

    @Override
    public MatchDto getMatchById(Long id) {
        MatchEntity match = matchRepository.findById(id).orElseThrow();
        return MatchMapper.toDto(match);
    }
    @Override
    public Optional<MatchDto> findFirstByTeamAndMatchDate(Long teamId, LocalDateTime matchDate) {
        return matchRepository.findFirstByTeamIdAndMatchDate(teamId, matchDate)
                .map(MatchMapper::toDto);
    }
    @Override
    public void saveMatch(MatchDto matchDto) {
        TeamEntity team = teamRepository.findById(matchDto.getTeamId()).orElseThrow();
        MatchEntity entity = MatchMapper.toEntity(matchDto, team);
        matchRepository.save(entity);
    }

    @Override
    public void deleteMatch(Long id) {
        matchRepository.deleteById(id);
    }

    }


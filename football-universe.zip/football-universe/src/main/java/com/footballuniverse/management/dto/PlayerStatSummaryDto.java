package com.footballuniverse.management.dto; // [ADD]

import lombok.Getter; import lombok.Setter;

@Getter @Setter
public class PlayerStatSummaryDto { // [ADD]
    private Long playerId;
    private String username;

    private int minutes;
    private int goals;
    private int assists;
    private int yellow;
    private int red;
    private int absences;
    private int formScore;
}

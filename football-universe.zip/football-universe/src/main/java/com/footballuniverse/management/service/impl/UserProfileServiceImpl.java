package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.UserProfileService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserProfileServiceImpl implements UserProfileService {

    private final UserRepository users;


    public UserProfileServiceImpl(UserRepository users) {
        this.users = users;
    }

    @Override
    @Transactional(readOnly = true)
    public UserProfileDto getProfile(String username) {
        UserEntity u = users.findByUsername(username).orElseThrow();

        UserProfileDto dto = new UserProfileDto();
        dto.setUsername(u.getUsername());
        dto.setEmail(u.getEmail());

        // Ако UserEntity има тези полета — попълни ги; ако нямаш, остават null (шаблонът ги крие)
        try { dto.setPosition(u.getPosition()); } catch (Exception ignored) {}
        try { dto.setRole(u.getRole() != null ? u.getRole().getRole().name() : null); } catch (Exception ignored) {}
        try { dto.setTeamName(u.getTeam() != null ? u.getTeam().getName() : null); } catch (Exception ignored) {}

        return dto;
    }

    @Override
    @Transactional
    public void updateProfile(String username, UserProfileDto form) {
        UserEntity u = users.findByUsername(username).orElseThrow();

        if (form.getEmail() != null) {
            u.setEmail(form.getEmail().trim());
        }
        try {
            if (form.getPosition() != null) {
                u.setPosition(form.getPosition().trim());
            }
        } catch (Exception ignored) {}

        users.save(u);
    }
}

package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.enums.EventType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface EventRepository extends JpaRepository<EventEntity, Long> {

    List<EventEntity> findAllByTeamIdAndDateTimeBetweenOrderByDateTimeAsc(
            Long teamId, LocalDateTime from, LocalDateTime to);

    // ако имаш enum EventType.MATCH
    @Query("""
       select coalesce(sum(e.homeGoals),0), coalesce(sum(e.awayGoals),0)
       from EventEntity e
       where e.team.id = :teamId and e.type = com.footballuniverse.management.enums.EventType.MATCH
       """)
    Object[] goals(@org.springframework.data.repository.query.Param("teamId") Long teamId);


    List<EventEntity> findAllByTeamIdAndTypeAndDateTimeBetweenOrderByDateTimeAsc(
            Long teamId, EventType type, LocalDateTime from, LocalDateTime to);
    Optional<EventEntity> findByIdAndTeamId(Long id, Long teamId);

    List<EventEntity> findAllByTeamIdOrderByDateTimeDesc(Long teamId);

    List<EventEntity> findAllByTeamIdAndTypeOrderByDateTimeDesc(Long teamId, EventType type);
}

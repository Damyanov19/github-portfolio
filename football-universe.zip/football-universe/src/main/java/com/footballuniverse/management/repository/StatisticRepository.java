package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.StatisticEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatisticRepository extends JpaRepository<StatisticEntity, Long> {
}

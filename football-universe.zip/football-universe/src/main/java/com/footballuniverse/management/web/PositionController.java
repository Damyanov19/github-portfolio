package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.PositionDto;
import com.footballuniverse.management.service.PositionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/positions")
public class PositionController {

    private final PositionService positionService;

    public PositionController(PositionService positionService) {
        this.positionService = positionService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("positions", positionService.findAll());
        return "position/position-list";
    }

    @GetMapping("/{id}")
    public String details(@PathVariable Long id, Model model) {
        model.addAttribute("position", positionService.findById(id));
        return "position/position-details";
    }

    @PostMapping
    public String create(@ModelAttribute PositionDto dto) {
        positionService.create(dto);
        return "redirect:/positions";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        positionService.delete(id);
        return "redirect:/positions";
    }
}

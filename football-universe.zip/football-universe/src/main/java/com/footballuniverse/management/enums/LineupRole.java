package com.footballuniverse.management.enums;

public enum LineupRole {
    STARTER, BENCH, NONE
}

package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<UserEntity, Long> {
    @EntityGraph(attributePaths = "role")
    Optional<UserEntity> findByUsername(String username);
    Optional<UserEntity> findByEmail(String email);

    List<UserEntity> findAllByTeam_Id(Long teamId);
    // [ADD]
    List<UserEntity> findAllByTeamIdOrderByUsernameAsc(Long teamId);

    // [ADD] – за търсене по username или email
    Optional<UserEntity> findByUsernameIgnoreCaseOrEmailIgnoreCase(String username, String email);

    // [ADD] – ако искаш проверка за брой админи в даден отбор
    long countByTeamIdAndRole_Role(Long teamId, UserRoleEnums role);

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);
}

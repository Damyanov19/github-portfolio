package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.mapper.TrainingMapper;
import com.footballuniverse.management.dto.TrainingDto;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.TrainingEntity;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.repository.TrainingRepository;
import com.footballuniverse.management.service.TrainingService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrainingServiceImpl implements TrainingService {

    private final TrainingRepository trainingRepository;
    private final TeamRepository teamRepository;

    public TrainingServiceImpl(TrainingRepository trainingRepository, TeamRepository teamRepository) {
        this.trainingRepository = trainingRepository;
        this.teamRepository = teamRepository;
    }

    @Override
    public List<TrainingDto> getAllTrainingsByTeam(Long teamId) {
        return trainingRepository.findAllByTeamIdOrderByDateTimeDesc(teamId).stream()
                .map(TrainingMapper::toDto)
                .toList();
    }

    @Override
    public void saveTraining(TrainingDto trainingDto) {
        TeamEntity team = teamRepository.findById(trainingDto.getTeamId()).orElseThrow();
        TrainingEntity entity = TrainingMapper.toEntity(trainingDto, team);
        trainingRepository.save(entity);
    }

    @Override
    public TrainingDto getTrainingById(Long id) {
        return trainingRepository.findById(id)
                .map(TrainingMapper::toDto)
                .orElseThrow();
    }

    @Override
    public void deleteTraining(Long id) {
        trainingRepository.deleteById(id);
    }
}

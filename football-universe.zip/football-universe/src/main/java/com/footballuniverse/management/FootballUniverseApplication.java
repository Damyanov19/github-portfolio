package com.footballuniverse.management;

import com.footballuniverse.management.entity.user.RoleEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.RoleRepository;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class FootballUniverseApplication {

	public static void main(String[] args) {
		SpringApplication.run(FootballUniverseApplication.class, args);
	}

}

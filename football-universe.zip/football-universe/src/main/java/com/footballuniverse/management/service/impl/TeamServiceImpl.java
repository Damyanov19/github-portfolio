package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.mapper.TeamMapper;
import com.footballuniverse.management.dto.TeamDto;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.service.TeamService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeamServiceImpl implements TeamService {

    private final TeamRepository teamRepository;

    public TeamServiceImpl(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }

    @Override
    public List<TeamDto> getAllTeams() {
        return teamRepository.findAll().stream()
                .map(TeamMapper::toDto)
                .toList();
    }

    @Override
    public TeamDto getById(Long id) {
        TeamEntity entity = teamRepository.findById(id).orElseThrow();
        return TeamMapper.toDto(entity);
    }

    @Override
    public void save(TeamDto teamDTO) {
        TeamEntity entity = TeamMapper.toEntity(teamDTO);
        teamRepository.save(entity);
    }

    @Override
    public void delete(Long id) {
        teamRepository.deleteById(id);
    }
}

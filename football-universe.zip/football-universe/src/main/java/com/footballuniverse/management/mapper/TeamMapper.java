package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.TeamDto;
import com.footballuniverse.management.entity.TeamEntity;

public interface TeamMapper {

    public static TeamDto toDto(TeamEntity entity) {
        TeamDto dto = new TeamDto();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setDescription(entity.getDescription());
        dto.setCountry(entity.getCountry());
        dto.setCity(entity.getCity());
        return dto;
    }

    public static TeamEntity toEntity(TeamDto dto) {
        TeamEntity entity = new TeamEntity();
        entity.setId(dto.getId());
        entity.setName(dto.getName());
        entity.setDescription(dto.getDescription());
        entity.setCountry(dto.getCountry());
        entity.setCity(dto.getCity());
        return entity;
    }
}

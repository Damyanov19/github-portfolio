package com.footballuniverse.management.repository; // [ADD]

import com.footballuniverse.management.entity.LineupItemEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LineupItemRepository extends JpaRepository<LineupItemEntity, Long> {
    List<LineupItemEntity> findAllByLineupIdOrderByOrderNoAsc(Long lineupId);

}

package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.FormationDto;

import java.util.List;

public interface FormationService {
    FormationDto createFormation(FormationDto formationDto);
    FormationDto updateFormation(Long id, FormationDto formationDto);
    void deleteFormation(Long id);
    FormationDto getFormationById(Long id);
    List<FormationDto> getAllFormations();
}

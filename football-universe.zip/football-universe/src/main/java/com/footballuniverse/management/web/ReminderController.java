package com.footballuniverse.management.web;

import com.footballuniverse.management.entity.ReminderEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.ReminderRepository;
import com.footballuniverse.management.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;

@Controller
@RequestMapping("/reminders")
@PreAuthorize("hasAnyRole('ADMIN','COACH')") // само Админ/Треньор управляват
public class ReminderController {

    private final ReminderRepository reminders;
    private final UserRepository users;

    public ReminderController(ReminderRepository reminders, UserRepository users) {
        this.reminders = reminders;
        this.users = users;
    }

    private TeamEntity currentTeam(Authentication auth) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();
        return u.getTeam();
    }

    @GetMapping
    public String list(Authentication auth, Model model) {
        Long teamId = currentTeam(auth).getId();
        model.addAttribute("items", reminders.findAllByTeamIdOrderByDueAtAsc(teamId));
        return "reminders/list";
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("reminder", new ReminderEntity());
        return "reminders/form";
    }

    @PostMapping
    public String create(@ModelAttribute("reminder") ReminderEntity r,
                         Authentication auth,
                         RedirectAttributes ra) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();
        r.setTeam(u.getTeam());
        r.setCreatedBy(u);
        if (r.getDueAt() == null) r.setDueAt(LocalDateTime.now().plusDays(1));
        reminders.save(r);
        ra.addFlashAttribute("success", "Напомнянето е създадено.");
        return "redirect:/reminders";
    }

    @GetMapping("/{id}/edit")
    public String edit(@PathVariable Long id, Authentication auth, Model model) {
        ReminderEntity r = reminders.findById(id).orElseThrow();
        if (!r.getTeam().getId().equals(currentTeam(auth).getId())) return "redirect:/reminders";
        model.addAttribute("reminder", r);
        return "reminders/form";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable Long id,
                         @ModelAttribute("reminder") ReminderEntity form,
                         Authentication auth,
                         RedirectAttributes ra) {
        ReminderEntity r = reminders.findById(id).orElseThrow();
        if (!r.getTeam().getId().equals(currentTeam(auth).getId())) return "redirect:/reminders";

        r.setTitle(form.getTitle());
        r.setDueAt(form.getDueAt());
        r.setNote(form.getNote());
        reminders.save(r);

        ra.addFlashAttribute("success", "Напомнянето е обновено.");
        return "redirect:/reminders";
    }

    @PostMapping("/{id}/toggle")
    public String toggle(@PathVariable Long id, Authentication auth) {
        ReminderEntity r = reminders.findById(id).orElseThrow();
        if (r.getTeam().getId().equals(currentTeam(auth).getId())) {
            r.setDone(!r.isDone());
            reminders.save(r);
        }
        return "redirect:/reminders";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, Authentication auth) {
        ReminderEntity r = reminders.findById(id).orElse(null);
        if (r != null && r.getTeam().getId().equals(currentTeam(auth).getId())) {
            reminders.delete(r);
        }
        return "redirect:/reminders";
    }
}

package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.PlayerDto;
import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.service.PlayerService;
import com.footballuniverse.management.service.TeamService;
import com.footballuniverse.management.service.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@RestController
@RequestMapping("/api/players")
public class PlayerController {

    private final PlayerService playerService;
    private final TeamService teamService;
    private final UserService userService;

    public PlayerController(PlayerService playerService, TeamService teamService, UserService userService) {
        this.playerService = playerService;
        this.teamService = teamService;
        this.userService = userService;
    }

    @PostMapping
    public PlayerDto create(@RequestBody PlayerDto dto) {
        return playerService.createPlayer(dto);
    }

    @PutMapping("/{id}")
    public PlayerDto update(@PathVariable Long id, @RequestBody PlayerDto dto) {
        return playerService.updatePlayer(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        playerService.deletePlayer(id);
    }

    @GetMapping("/{id}")
    public PlayerDto getById(@PathVariable Long id) {
        return playerService.getById(id);
    }

    @GetMapping
    public List<PlayerDto> getAll() {
        return playerService.getAll();
    }

    @GetMapping("/team/{teamId}")
    public List<PlayerDto> getByTeam(@PathVariable Long teamId) {
        return playerService.getByTeamId(teamId);
    }

    @GetMapping("/players")
public String showPlayers(Model model) {
    model.addAttribute("players", playerService.getAll());
    return "players";
}

    // Детайли за играч
    @GetMapping("/players/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','COACH','PLAYER')")
    public String details(@PathVariable Long id, Model model) {
        UserEntity p = userService.findById(id).orElseThrow();     // ако нямаш този метод – виж т.4
        model.addAttribute("player", p);
        return "players/details";                                   // templates/players/details.html
    }


    @GetMapping("/players/{id}/edit")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String editForm(@PathVariable Long id, Model model) {
        UserEntity p = userService.findById(id).orElseThrow();
        UserProfileDto form = userService.toUserProfileDto(p);      // удобен DTO за формата
        model.addAttribute("playerId", id);
        model.addAttribute("form", form);
        return "players/edit";                                      // templates/players/edit.html
    }


    // Запис на редакцията
    @PostMapping("/players/{id}/edit")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String edit(@PathVariable Long id,
                       @ModelAttribute("form") UserProfileDto form,
                       RedirectAttributes ra) {
        UserEntity p = userService.findById(id).orElseThrow();
        userService.applyProfile(p, form);                          // копира полетата от формата
        userService.save(p);
        ra.addFlashAttribute("success", "Играчът е обновен.");
        return "redirect:/team/players";
    }

@GetMapping("/players/new")
public String showCreateForm(Model model) {
    model.addAttribute("player", new PlayerDto());
    model.addAttribute("teams", teamService.getAllTeams()); // трябва да имаш teamService
    return "player-form";
}

@PostMapping("/players/save")
public String savePlayer(@ModelAttribute PlayerDto playerDto) {
    playerService.createPlayer(playerDto);
    return "redirect:/players";
}

@GetMapping("/players/edit/{id}")
public String showEditForm(@PathVariable Long id, Model model) {
    model.addAttribute("player", playerService.getById(id));
    model.addAttribute("teams", teamService.getAllTeams());
    return "player-form";
}

@PostMapping("/players/update/{id}")
public String updatePlayer(@PathVariable Long id, @ModelAttribute PlayerDto dto) {
    playerService.updatePlayer(id, dto);
    return "redirect:/players";
}

@GetMapping("/players/delete/{id}")
public String deletePlayer(@PathVariable Long id) {
    playerService.deletePlayer(id);
    return "redirect:/players";
}
}

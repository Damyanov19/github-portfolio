package com.footballuniverse.management.enums;

public enum UserRoleEnums {
    ADMIN,
    COACH,
    PLAYER
}

package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.TeamDto;

import java.util.List;

public interface TeamService {
    List<TeamDto> getAllTeams();
    TeamDto getById(Long id);
    void save(TeamDto teamDto);
    void delete(Long id);
}

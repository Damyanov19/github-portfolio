package com.footballuniverse.management.entity;

import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.AgeGroupsEnum;
import jakarta.persistence.*;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "teams")
public class TeamEntity extends BaseEntity{

    @Column(nullable = false, unique = true)
    private String name;

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    private String country;

    @Column
    private String city;

    @OneToMany(mappedBy = "team", cascade = CascadeType.ALL)
    private Set<UserEntity> members;


    @Column(name = "crest_url")
    private String crestUrl;

    @Enumerated(EnumType.STRING)
    private AgeGroupsEnum ageGroupsEnum;


    @Column
    private String contacts;


}

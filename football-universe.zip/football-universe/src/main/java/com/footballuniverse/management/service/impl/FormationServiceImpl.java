package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.dto.FormationDto;
import com.footballuniverse.management.entity.FormationEntity;
import com.footballuniverse.management.mapper.FormationMapper;
import com.footballuniverse.management.repository.FormationRepository;
import com.footballuniverse.management.service.FormationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FormationServiceImpl implements FormationService {

    private final FormationRepository formationRepository;

    @Override
    public FormationDto createFormation(FormationDto formationDto) {
        FormationEntity formation = FormationMapper.toEntity(formationDto);
        return FormationMapper.toDto(formationRepository.save(formation));
    }

    @Override
    public FormationDto updateFormation(Long id, FormationDto formationDto) {
        FormationEntity existing = formationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Formation not found"));
        existing.setName(formationDto.getName());
        existing.setDescription(formationDto.getDescription());
        return FormationMapper.toDto(formationRepository.save(existing));
    }

    @Override
    public void deleteFormation(Long id) {
        formationRepository.deleteById(id);
    }

    @Override
    public FormationDto getFormationById(Long id) {
        return formationRepository.findById(id)
                .map(FormationMapper::toDto)
                .orElseThrow(() -> new RuntimeException("Formation not found"));
    }

    @Override
    public List<FormationDto> getAllFormations() {
        return formationRepository.findAll().stream()
                .map(FormationMapper::toDto)
                .collect(Collectors.toList());
    }
}

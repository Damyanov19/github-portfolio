package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.MissedTrainingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MissedTrainingRepository extends JpaRepository<MissedTrainingEntity, Long> {
}

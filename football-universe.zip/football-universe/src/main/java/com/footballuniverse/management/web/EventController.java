package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.EventDto;
import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.EventType;
import com.footballuniverse.management.repository.EventRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.EventService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/events")
public class EventController {

    private final EventService service;
    private final UserRepository users;
    
    private final EventRepository events;

    public EventController(EventService service, UserRepository users, EventRepository events) {
        this.service = service; this.users = users;
        this.events = events;
    }

    private TeamEntity team(Authentication auth) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();
        return u.getTeam();
    }

    @GetMapping
    public String list(@RequestParam(required = false) EventType type, Authentication auth, Model model) {
        model.addAttribute("events", service.listAll(team(auth), type));
        model.addAttribute("filterType", type);
        Long teamId = users.findByUsername(auth.getName())
                .orElseThrow()
                .getTeam()
                .getId(); /* вземи текущ teamId от auth */ ;

        List<EventEntity> items;
        LocalDateTime from = LocalDateTime.now().minusMonths(1);
        LocalDateTime to   = LocalDateTime.now().plusMonths(6);

        if (type != null) {
            items = events.findAllByTeamIdAndTypeAndDateTimeBetweenOrderByDateTimeAsc(
                    teamId, type, from, to);
        } else {
            items = events.findAllByTeamIdAndDateTimeBetweenOrderByDateTimeAsc(
                    teamId, from, to);
        }

        model.addAttribute("events", items);
        model.addAttribute("selectedType", type);
 
        return "events/list";
    }

    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    @GetMapping("/new")
    public String createForm(@RequestParam EventType type, Model model) {
        EventDto form = new EventDto();
        form.setType(type);
        model.addAttribute("form", form);
        return "events/form";
    }

    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    @PostMapping
    public String create(@ModelAttribute("form") EventDto form, Authentication auth) {
        service.create(team(auth), form);
        return "redirect:/events";
    }

    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Authentication auth, Model model) {
        var e = service.getOwned(id, team(auth));
        EventDto form = new EventDto();
        form.setType(e.getType());
        form.setDateTime(e.getDateTime().toString().substring(0,16)); // yyyy-MM-ddTHH:mm
        form.setDurationMin(e.getDurationMin());
        form.setLocation(e.getLocation());
        form.setNotes(e.getNotes());
        model.addAttribute("eventId", id);
        model.addAttribute("form", form);
        return "events/form";
    }

    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    @PostMapping("/{id}")
    public String update(@PathVariable Long id, @ModelAttribute("form") EventDto form, Authentication auth) {
        service.update(id, team(auth), form);
        return "redirect:/events";
    }

    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, Authentication auth) {
        service.delete(id, team(auth));
        return "redirect:/events";
    }
}

package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.FormationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FormationRepository extends JpaRepository<FormationEntity, Long> {
}

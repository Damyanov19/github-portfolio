package com.footballuniverse.management.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FormationEntity extends BaseEntity {

    private String name; // Например: "4-4-2", "4-3-3", "3-5-2"

    private String description; // Допълнително описание (по избор)
}

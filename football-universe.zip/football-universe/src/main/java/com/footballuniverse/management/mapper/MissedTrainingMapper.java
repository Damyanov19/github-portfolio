package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.MissedTrainingDto;
import com.footballuniverse.management.entity.MissedTrainingEntity;
import com.footballuniverse.management.entity.PlayerEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface MissedTrainingMapper {

    public static MissedTrainingEntity toEntity(MissedTrainingDto dto, PlayerEntity player) {
        MissedTrainingEntity entity = new MissedTrainingEntity();
        entity.setId(dto.getId());
        entity.setDate(dto.getDate());
        entity.setLocation(dto.getLocation());
        entity.setReason(dto.getReason());
        entity.setPlayer(player);
        return entity;
    }

    public static MissedTrainingDto toDto(MissedTrainingEntity entity) {
        MissedTrainingDto dto = new MissedTrainingDto();
        dto.setId(entity.getId());
        dto.setDate(entity.getDate());
        dto.setLocation(entity.getLocation());
        dto.setReason(entity.getReason());
        dto.setPlayerId(entity.getPlayer().getId());
        return dto;
    }
}

package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.TeamMessageCommentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TeamMessageCommentRepository extends JpaRepository<TeamMessageCommentEntity, Long> {
    List<TeamMessageCommentEntity> findByMessageIdOrderByCreatedAtAsc(Long messageId);
}

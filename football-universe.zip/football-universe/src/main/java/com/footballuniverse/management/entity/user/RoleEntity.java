package com.footballuniverse.management.entity.user;

import com.footballuniverse.management.entity.BaseEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "roles")
public class RoleEntity extends BaseEntity {

/*    @Column(nullable = false, unique = true)*/
   /* private String name;  */// Примери: ADMIN, COACH, PLAYER

    @NotNull
    @Column(unique = true)
    @Enumerated(EnumType.STRING)
    private UserRoleEnums role;

    public UserRoleEnums getRole() {
        return role;
    }

    public RoleEntity setRole(UserRoleEnums role) {
        this.role = role;
        return this;
    }
}

package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.AttendanceEntity;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AttendanceRepository extends JpaRepository<AttendanceEntity, Long> {
    @EntityGraph(attributePaths = "player")
    List<AttendanceEntity> findAllByEventId(Long eventId);
    Optional<AttendanceEntity> findByEventIdAndPlayerId(Long eventId, Long playerId);

    boolean existsByEventIdAndPlayerId(Long eventId, Long playerId);
}

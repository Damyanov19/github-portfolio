package com.footballuniverse.management.repository;

import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.entity.PlayerEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PlayerRepository extends JpaRepository<PlayerEntity, Long> {
    List<PlayerEntity> findByTeamId(Long teamId);

}

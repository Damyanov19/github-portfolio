package com.footballuniverse.management.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatisticDto {
    private Long id;
    private Long playerId;
    private Long matchId;
    private int goals;
    private int assists;
    private int yellowCards;
    private int redCards;
    private int minutesPlayed;
    private boolean substituted;
}

package com.footballuniverse.management.dto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionDto {

    private Long id;
    private String name;

    // Getters and Setters
    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }
}

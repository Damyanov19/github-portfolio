package com.footballuniverse.management.service;

import com.footballuniverse.management.entity.AttendanceEntity;
import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.AttendanceStatusEnum;

import java.util.List;

public interface AttendanceService {

    List<AttendanceEntity> listForEvent(EventEntity event);

    void setForPlayer(EventEntity event,
                      UserEntity player,
                      AttendanceStatusEnum status,
                      String reason);

    EventEntity loadAndCheckEventOwned(Long eventId, TeamEntity team);

    AttendanceEntity rsvp(EventEntity event,
                          UserEntity player,
                          AttendanceStatusEnum status,
                          String reason);
}

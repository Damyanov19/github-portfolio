package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.FormationDto;
import com.footballuniverse.management.service.FormationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/formations")
@RequiredArgsConstructor
public class FormationController {

    private final FormationService formationService;

    @GetMapping
    public String listFormations(Model model) {
        model.addAttribute("formations", formationService.getAllFormations());
        return "formation/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("formation", new FormationDto());
        return "formation/create";
    }

    @PostMapping("/create")
    public String createFormation(@ModelAttribute FormationDto formationDto) {
        formationService.createFormation(formationDto);
        return "redirect:/formations";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        model.addAttribute("formation", formationService.getFormationById(id));
        return "formation/edit";
    }

    @PostMapping("/edit/{id}")
    public String updateFormation(@PathVariable Long id, @ModelAttribute FormationDto formationDto) {
        formationService.updateFormation(id, formationDto);
        return "redirect:/formations";
    }

    @GetMapping("/delete/{id}")
    public String deleteFormation(@PathVariable Long id) {
        formationService.deleteFormation(id);
        return "redirect:/formations";
    }
}

package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.entity.AttendanceEntity;
import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.AttendanceStatusEnum;
import com.footballuniverse.management.repository.AttendanceRepository;
import com.footballuniverse.management.repository.EventRepository;
import com.footballuniverse.management.service.AttendanceService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@Transactional
public class AttendanceServiceImpl implements AttendanceService {

    private final AttendanceRepository attendanceRepo;
    private final EventRepository eventRepo;

    public AttendanceServiceImpl(AttendanceRepository attendanceRepo, EventRepository eventRepo) {
        this.attendanceRepo = attendanceRepo;
        this.eventRepo = eventRepo;
    }

    /** Връща всички присъствия за конкретно събитие (бивша "тренировка"). */
    @Override
    @Transactional(readOnly = true)
    public List<AttendanceEntity> listForEvent(EventEntity event) {
        return attendanceRepo.findAllByEventId(event.getId());
    }

    /** RSVP за играч към конкретно събитие. */
    @Override
    public AttendanceEntity rsvp(EventEntity event,
                                 UserEntity player,
                                 AttendanceStatusEnum status,
                                 String reason) {
        AttendanceEntity a = attendanceRepo
                .findByEventIdAndPlayerId(event.getId(), player.getId())
                .orElseGet(() -> {
                    AttendanceEntity na = new AttendanceEntity();
                    na.setEvent(event);
                    na.setPlayer(player);
                    na.setStatus(AttendanceStatusEnum.UNDECIDED);
                    return na;
                });
        a.setStatus(status);
        a.setReason(reason);
        return attendanceRepo.save(a);
    }

    /** Сетване на статус за конкретен играч (делегира към rsvp). */
    @Override
    public void setForPlayer(EventEntity event,
                             UserEntity player,
                             AttendanceStatusEnum status,
                             String reason) {
        rsvp(event, player, status, reason);
    }

    /** Зарежда събитие по id и проверява собствеността към отбор. */
    @Override
    @Transactional(readOnly = true)
    public EventEntity loadAndCheckEventOwned(Long eventId, TeamEntity team) {
        // Запазваме името на метода за съвместимост с интерфейса, но вече работим с Event
        return eventRepo.findByIdAndTeamId(eventId, team.getId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Събитието не е намерено или не е от вашия отбор"));
    }
}

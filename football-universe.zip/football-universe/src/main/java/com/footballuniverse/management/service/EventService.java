package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.EventDto;
import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.enums.EventType;

import java.util.List;

public interface EventService {
    List<EventEntity> listAll(TeamEntity team, EventType typeFilter);
    EventEntity create(TeamEntity team, EventDto form);
    EventEntity update(Long id, TeamEntity team, EventDto form);
    void delete(Long id, TeamEntity team);
    EventEntity getOwned(Long id, TeamEntity team);
}

package com.footballuniverse.web;

import com.footballuniverse.management.dto.MissedTrainingDto;
import com.footballuniverse.management.service.MissedTrainingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/missed-trainings")
public class MissedTrainingController {

    private final MissedTrainingService missedTrainingService;

    public MissedTrainingController(MissedTrainingService missedTrainingService) {
        this.missedTrainingService = missedTrainingService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("missedTrainings", missedTrainingService.findAll());
        return "missed-trainings/list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("missedTraining", new MissedTrainingDto());
        return "missed-trainings/add";
    }

    @PostMapping("/add")
    public String add(@ModelAttribute("missedTraining") MissedTrainingDto dto) {
        missedTrainingService.create(dto);
        return "redirect:/missed-trainings";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        missedTrainingService.delete(id);
        return "redirect:/missed-trainings";
    }
}

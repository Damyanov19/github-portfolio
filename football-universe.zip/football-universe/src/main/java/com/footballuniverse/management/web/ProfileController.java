package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.PasswordChangeDto;
import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/profile")
public class ProfileController {

    private final UserService userService;
    private final UserRepository users;

    public ProfileController(UserService userService, UserRepository users) {
        this.userService = userService;
        this.users = users;
    }

    private UserEntity requireCurrentUser(Authentication auth) {
        if (auth == null || auth.getName() == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Няма активна сесия");
        }
        return userService.findEntityByUsername(auth.getName())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Потребителят не е намерен"));
    }


    private static UserProfileDto toDto(UserEntity u) {
        if (u == null) return new UserProfileDto();
        UserProfileDto dto = new UserProfileDto();
        dto.setFirstName(u.getFirstName());
        dto.setLastName(u.getLastName());
        dto.setUsername(u.getUsername());
        dto.setEmail(u.getEmail());

        try { dto.setPosition(u.getPosition()); } catch (Exception ignored) {}
        try { dto.setNumber(u.getNumber() != null ? u.getNumber() : null); } catch (Exception ignored) {}
        dto.setRole(u.getRole() != null ? u.getRole().getRole().name() : null);
        dto.setTeamName(u.getTeam() != null ? u.getTeam().getName() : null);
        return dto;
    }

    @GetMapping
    public String view(Authentication auth, Model model) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();

        UserProfileDto pf = toForm(u);
        model.addAttribute("profile", pf);
        model.addAttribute("pwd", new PasswordChangeDto());

        return "profile/view";
    }

    @PostMapping
    public String updateFromView(@ModelAttribute("profile") UserProfileDto form,
                                 Authentication auth,
                                 RedirectAttributes ra) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();
        applyProfile(u, form, false);
        users.save(u);
        ra.addFlashAttribute("success", "Профилът е обновен.");
        return "redirect:/profile";
    }

    @GetMapping("/edit")
    public String edit(Authentication auth, Model model) {
        UserEntity u = requireCurrentUser(auth);
        model.addAttribute("profile", toDto(u));
        model.addAttribute("form", toDto(u));
        return "profile/edit";
    }


    @PostMapping("/edit")
    public String update(@ModelAttribute("form") UserProfileDto form,
                         Authentication auth,
                         RedirectAttributes ra) {
        UserEntity u = requireCurrentUser(auth);

        if (form.getEmail() != null) u.setEmail(form.getEmail().trim());
        if (form.getFirstName() != null) u.setFirstName(form.getFirstName().trim());
        if (form.getLastName() != null) u.setLastName(form.getLastName().trim());

        if (form.getPosition() != null) u.setPosition(form.getPosition().trim());
        if (form.getNumber() != null)   u.setNumber(form.getNumber());



        userService.save(u);
        ra.addFlashAttribute("success", "Профилът е обновен.");
        return "redirect:/profile";
    }

    // CHANGE PASSWORD
    @PostMapping("/password")
    public String changePassword(@ModelAttribute("pwd") PasswordChangeDto dto,
                                 Authentication auth,
                                 RedirectAttributes ra) {
        requireCurrentUser(auth);
        userService.changeMyPassword(auth.getName(), dto.getCurrentPassword(), dto.getNewPassword());
        ra.addFlashAttribute("success", "Паролата е променена.");
        return "redirect:/profile";
    }
    private static UserProfileDto toForm(UserEntity u) {
        UserProfileDto f = new UserProfileDto();
        f.setUsername(u.getUsername());
        f.setFirstName(u.getFirstName());
        f.setLastName(u.getLastName());
        f.setEmail(u.getEmail());
        f.setPosition(u.getPosition());   // ако тези полета липсват в UserEntity – махни ги и от шаблоните
        f.setNumber(u.getNumber());
        f.setRole(u.getRole() != null ? u.getRole().getRole().name() : null);
        f.setTeamName(u.getTeam() != null ? u.getTeam().getName() : null);
        return f;
    }

    private static void applyProfile(UserEntity u, UserProfileDto f, boolean allowRoleTeamChange) {
        // username/role/teamName са readonly в шаблоните – не ги пипаме
        u.setFirstName(emptyToNull(f.getFirstName()));
        u.setLastName(emptyToNull(f.getLastName()));
        u.setEmail(emptyToNull(f.getEmail()));
        u.setPosition(emptyToNull(f.getPosition())); // махни, ако нямаш поле
        u.setNumber(f.getNumber());                  // махни, ако нямаш поле

    }

    private static String emptyToNull(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }
}

package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.dto.EventDto;
import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.enums.EventType;
import com.footballuniverse.management.repository.EventRepository;
import com.footballuniverse.management.service.EventService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@Transactional
public class EventServiceImpl implements EventService {

    private final EventRepository repo;
    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    public EventServiceImpl(EventRepository repo) { this.repo = repo; }

    @Override
    public List<EventEntity> listAll(TeamEntity team, EventType typeFilter) {
        if (typeFilter == null) return repo.findAllByTeamIdOrderByDateTimeDesc(team.getId());
        return repo.findAllByTeamIdAndTypeOrderByDateTimeDesc(team.getId(), typeFilter);
    }

    @Override
    public EventEntity create(TeamEntity team, EventDto form) {
        EventEntity e = new EventEntity();
        apply(team, form, e);
        return repo.save(e);
    }

    @Override
    public EventEntity update(Long id, TeamEntity team, EventDto form) {
        EventEntity e = getOwned(id, team);
        apply(team, form, e);
        return repo.save(e);
    }

    @Override
    public void delete(Long id, TeamEntity team) {
        EventEntity e = getOwned(id, team);
        repo.delete(e);
    }

    @Override
    public EventEntity getOwned(Long id, TeamEntity team) {
        EventEntity e = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Невалидно събитие"));
        if (!e.getTeam().getId().equals(team.getId())) {
            throw new IllegalArgumentException("Нямате права върху това събитие");
        }
        return e;
    }

    private void apply(TeamEntity team, EventDto form, EventEntity e) {
        e.setTeam(team);
        e.setType(form.getType());
        e.setDateTime(LocalDateTime.parse(form.getDateTime(), DTF));
        e.setDurationMin(form.getDurationMin());
        e.setLocation(form.getLocation().trim());
        e.setNotes(form.getNotes());
    }
}

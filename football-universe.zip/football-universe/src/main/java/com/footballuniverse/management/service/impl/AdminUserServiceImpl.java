package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.RoleEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.repository.RoleRepository;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.AdminUserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AdminUserServiceImpl implements AdminUserService {
    private final UserRepository users;
    private final TeamRepository teams;
    private final RoleRepository roles;
    private final PasswordEncoder enc;

    public AdminUserServiceImpl(UserRepository users, TeamRepository teams, RoleRepository roles, PasswordEncoder enc) {
        this.users = users;
        this.teams = teams;
        this.roles = roles;
        this.enc = enc;
    }


    @Override
    public void addExistingUserToTeam(Long userId, Long teamId, UserRoleEnums role) {
        UserEntity u = users.findById(userId).orElseThrow();
        TeamEntity t = teams.findById(teamId).orElseThrow();
        RoleEntity r = roles.findByRole(role).orElseThrow();
        u.setTeam(t);
        u.setRole(r);
        users.save(u);
    }

    @Override
    public Long createUserInTeam(String username, String email, String rawPassword, Long teamId, UserRoleEnums role) {
        if (users.existsByUsername(username)) throw new IllegalArgumentException("Име е заето");
        if (users.existsByEmail(email)) throw new IllegalArgumentException("Имейл е зает");
        TeamEntity t = teams.findById(teamId).orElseThrow();
        RoleEntity r = roles.findByRole(role).orElseThrow();

        UserEntity u = new UserEntity();
        u.setUsername(username);
        u.setEmail(email);
        u.setPasswordHash(enc.encode(rawPassword));
        u.setTeam(t);
        u.setRole(r);
        users.save(u);
        return u.getId();
    }

    @Override
    public void changeUserRole(Long userId, UserRoleEnums role) {
        UserEntity u = users.findById(userId).orElseThrow();
        RoleEntity r = roles.findByRole(role).orElseThrow();
        u.setRole(r);
        users.save(u);
    }

    @Override
    public void removeUserFromTeam(Long userId) {
        UserEntity u = users.findById(userId).orElseThrow();
        u.setTeam(null);
        users.save(u);
    }
}


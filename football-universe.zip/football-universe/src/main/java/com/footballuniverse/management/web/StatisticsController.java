package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.MatchDto;
import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.EventType;
import com.footballuniverse.management.enums.UserRoleEnums;                 // [ADD]
import com.footballuniverse.management.repository.EventRepository;
import com.footballuniverse.management.repository.MatchRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.MatchService;               // [ADD]
import com.footballuniverse.management.service.StatisticsService;
import com.footballuniverse.management.service.UserService;                // [ADD]
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;       // [ADD]

@Controller
@RequestMapping("/stats")
@PreAuthorize("hasAnyRole('ADMIN','COACH')")
public class StatisticsController {

    private final StatisticsService stats;
    private final UserRepository users;
    private final MatchService matchService;                                // [ADD]
    private final UserService userService;
    private final EventRepository events;

    private final MatchRepository matchRepository;
    // [ADD]

    public StatisticsController(StatisticsService stats,
                                UserRepository users,
                                MatchService matchService,
                                UserService userService, EventRepository events, MatchRepository matchRepository) {
        this.stats = stats;
        this.users = users;
        this.matchService = matchService;
        this.userService = userService;
        this.events = events;

        this.matchRepository = matchRepository;
    }

    @GetMapping("/players")
    public String teamPlayers(Authentication auth, Model model) {
        UserEntity me = users.findByUsername(auth.getName()).orElseThrow();
        var teamId = me.getTeam().getId();

        model.addAttribute("summaries", stats.getTeamPlayerSummaries(teamId));

        var teamPlayers = users.findAllByTeamIdOrderByUsernameAsc(teamId);
        model.addAttribute("teamPlayers", teamPlayers);


        var teamMatches = matchService.getAllMatchesByTeam(teamId);
        model.addAttribute("teamMatches", teamMatches);


        if (teamMatches == null || teamMatches.isEmpty()) {
            var evMatches = events.findAllByTeamIdAndTypeOrderByDateTimeDesc(teamId, EventType.MATCH);
            var fallback = evMatches.stream().map(ev -> {
                var dto = new MatchDto();
                dto.setId(ev.getId());
                dto.setMatchDate(ev.getDateTime());
                dto.setOpponent(ev.getOpponent());
                dto.setLocation(ev.getLocation());
                dto.setTeamId(teamId);
                return dto;
            }).toList();
            model.addAttribute("fallbackEvents", fallback);
        }

        return "stats/players";
    }


    private String sanitizeOpponent(String opp) {
        return (opp == null || opp.trim().isEmpty()) ? "Неизвестен противник" : opp.trim();
    }

    @PostMapping("/players/add-stat")
    public String addPlayerStat(@RequestParam Long matchId,
                                @RequestParam Long playerId,
                                @RequestParam(required = false) Integer minutes,
                                @RequestParam(required = false) Integer goals,
                                @RequestParam(required = false) Integer assists,
                                @RequestParam(required = false) Integer yellow,
                                @RequestParam(required = false) Integer red,
                                RedirectAttributes ra) {
        Long effectiveMatchId = matchId;

        // [ADD] ако такъв Match няма, опитай като Event → създай Match от него
        if (!matchRepository.existsById(matchId)) {
            EventEntity ev = events.findById(matchId).orElse(null);
            if (ev != null) {
                MatchDto dto = new MatchDto();
                dto.setMatchDate(ev.getDateTime());
                dto.setOpponent(sanitizeOpponent(ev.getOpponent()));
                dto.setLocation(ev.getLocation());
                dto.setTeamId(ev.getTeam().getId());
                matchService.saveMatch(dto);

                // намери току-що създадения Match (по най-сигурното при теб – например най-новия за този team+date)
                var created = matchRepository.findTopByTeamIdAndMatchDateOrderByIdDesc(ev.getTeam().getId(), ev.getDateTime());
                if (created != null) {
                    effectiveMatchId = created.getId();
                }
            }
        }

        stats.upsertMatchPlayerStat(effectiveMatchId, playerId, minutes, goals, assists, yellow, red,
                null, null, null, null);

        ra.addFlashAttribute("success", "Статистиката за играча е записана.");
        return "redirect:/stats/players";
    }


    // [ADD] Добавяне на СЪЩЕСТВУВАЩ потребител към отбора (по username/email) като PLAYER (+ опционална позиция)
    @PostMapping("/players/add-member")
    public String addMember(Authentication auth,
                            @RequestParam String usernameOrEmail,
                            @RequestParam(required = false) String position,
                            RedirectAttributes ra) {
        try {
            userService.addMemberToMyTeam(usernameOrEmail, UserRoleEnums.PLAYER, position, auth.getName());
            ra.addFlashAttribute("success", "Играчът е добавен към отбора.");
        } catch (Exception ex) {
            ra.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/stats/players";
    }


    @PostMapping("/players/set-form")
    public String setForm(@RequestParam Long playerId,
                          @RequestParam int formScore,
                          RedirectAttributes ra) {
        stats.setPlayerFormScore(playerId, Math.max(0, Math.min(10, formScore)));
        ra.addFlashAttribute("success", "Формата е записана.");
        return "redirect:/stats/players";
    }

}

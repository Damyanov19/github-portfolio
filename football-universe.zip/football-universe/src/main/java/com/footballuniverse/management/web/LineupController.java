package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.LineupDto;
import com.footballuniverse.management.entity.EventEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.LineupRole;
import com.footballuniverse.management.mapper.LineupMapper;
import com.footballuniverse.management.repository.EventRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.LineupService;
import com.footballuniverse.management.service.MatchService;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;

@Controller
@RequestMapping("/events/{eventId}/lineup")
public class LineupController {

    private final LineupService lineupService;
    private final UserRepository users;
    private final EventRepository events;

    private final MatchService matchService;

    public LineupController(LineupService lineupService,
                            UserRepository users,
                            EventRepository events, MatchService matchService) {
        this.lineupService = lineupService;
        this.users = users;
        this.events = events;
        this.matchService = matchService;
    }

    private TeamEntity currentTeam(Authentication auth) {
        UserEntity u = users.findByUsername(auth.getName()).orElseThrow();
        return u.getTeam();
    }

    private EventEntity ownedMatch(Long eventId, Authentication auth) {
        TeamEntity team = currentTeam(auth);
        EventEntity e = events.findById(eventId).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Събитието не съществува"));
        if (!Objects.equals(e.getTeam().getId(), team.getId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Нямате права за този мач");
        }
        return e;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','COACH','PLAYER')")
    public String view(@PathVariable Long eventId, Authentication auth, Model model) {
        TeamEntity team = currentTeam(auth);
        EventEntity e = ownedMatch(eventId, auth);
        var lineup = lineupService.getForEvent(eventId, team.getId());

        var players = users.findAllByTeamIdOrderByUsernameAsc(team.getId());
        var form = LineupMapper.toDto(lineup);

        model.addAttribute("event", e);
        model.addAttribute("lineup", lineup);
        model.addAttribute("form", form);

        matchService.findFirstByTeamAndMatchDate(team.getId(), e.getDateTime())
                .ifPresent(m -> model.addAttribute("opponentName", m.getOpponent()));

        return "lineup/view";
    }

    @GetMapping("/edit")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String edit(@PathVariable Long eventId, Authentication auth, Model model) {
        TeamEntity team = currentTeam(auth);
        EventEntity e = ownedMatch(eventId, auth);

        List<UserEntity> players = users.findAllByTeamIdOrderByUsernameAsc(team.getId()).stream()
                .filter(u -> u.getRole() != null && u.getRole().getRole().name().equals("PLAYER"))
                .sorted(Comparator.comparing(UserEntity::getUsername))
                .toList();

        var existing = lineupService.getForEvent(eventId, team.getId());
        LineupDto form = LineupMapper.toDto(existing);

        model.addAttribute("event", e);
        model.addAttribute("players", players);
        model.addAttribute("form", form);
        model.addAttribute("LineupRole", LineupRole.class);
        return "lineup/form";
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String save(@PathVariable Long eventId,
                       @ModelAttribute("form") LineupDto form,
                       Authentication auth,
                       RedirectAttributes ra) {
        TeamEntity team = currentTeam(auth);
        lineupService.saveForEvent(eventId, team, auth.getName(), form);
        ra.addFlashAttribute("success", "Съставът е записан.");
        return "redirect:/events/" + eventId + "/lineup";
    }

    @PostMapping("/delete")
    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    public String delete(@PathVariable Long eventId, Authentication auth, RedirectAttributes ra) {
        TeamEntity team = currentTeam(auth);
        lineupService.deleteForEvent(eventId, team.getId());
        ra.addFlashAttribute("success", "Съставът е изтрит.");
        return "redirect:/events/" + eventId + "/lineup";
    }
}

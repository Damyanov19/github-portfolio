package com.footballuniverse.management.repository;

import com.footballuniverse.management.entity.TrainingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TrainingRepository extends JpaRepository<TrainingEntity, Long> {
    Optional<TrainingEntity> findByIdAndTeamId(Long id, Long teamId);

    List<TrainingEntity> findAllByTeamIdOrderByDateTimeDesc(Long teamId);


}


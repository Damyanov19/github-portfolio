package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.UserDto;
import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.dto.UserRegistrationDto;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.UserRoleEnums;

import java.util.List;
import java.util.Optional;

public interface UserService {
    List<UserDto> getAllUsers();
    UserDto getUserByUsername(String username);

    Optional<UserEntity> findEntityByUsername(String username);
    void createUser(UserDto dto);
    UserEntity save(UserEntity user);

    void registerUser(UserRegistrationDto dto);

    void addMemberToMyTeam(String usernameOrEmail, UserRoleEnums role, String position, String currentAdminUsername);


    void changeMemberRole(Long memberId, UserRoleEnums newRole, String currentAdminUsername);


    void removeMember(Long memberId, String currentAdminUsername);


    //  намиране по id за редакция
    Optional<UserEntity> findById(Long id);

    // удобни мапъри за екрана за редакция
    UserProfileDto toUserProfileDto(UserEntity u);
    void applyProfile(UserEntity u, UserProfileDto dto);

    boolean userExists(String username, String email);

    UserProfileDto getMyProfile(String username);
    void updateMyProfile(String username, UserProfileDto dto);
    void changeMyPassword(String username, String currentPass, String newPass);


}

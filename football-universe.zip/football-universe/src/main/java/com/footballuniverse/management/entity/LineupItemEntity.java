// [ADD]
package com.footballuniverse.management.entity;

import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.LineupRole;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "lineup_items")
public class LineupItemEntity extends BaseEntity {

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "lineup_id", nullable = false)
    private LineupEntity lineup;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "player_id", nullable = false)
    private UserEntity player;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    private LineupRole role; // STARTER / SUB

    @Column(length = 8)
    private String position; // напр. "GK","CB","ST"...

    @Column(name = "order_no")
    private Integer orderNo;

    private Integer shirtNo;
    private Integer minuteIn;
    private Integer minuteOut;

    // getters/setters
    public LineupEntity getLineup() { return lineup; }
    public void setLineup(LineupEntity lineup) { this.lineup = lineup; }

    public UserEntity getPlayer() { return player; }
    public void setPlayer(UserEntity player) { this.player = player; }

    public LineupRole getRole() { return role; }
    public void setRole(LineupRole role) { this.role = role; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public Integer getOrderNo() { return orderNo; }
    public void setOrderNo(Integer orderNo) { this.orderNo = orderNo; }
}

package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.MissedTrainingDto;

import java.util.List;

public interface MissedTrainingService {

    MissedTrainingDto create(MissedTrainingDto dto);
    List<MissedTrainingDto> findAll();
    MissedTrainingDto findById(Long id);
    void delete(Long id);
}

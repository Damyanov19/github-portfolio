package com.footballuniverse.management.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(
        method={RequestMethod.POST,RequestMethod.GET}
)

public class LoginController {

    @GetMapping("/login")
    public String login() {
        return "login"; // това сочи към login.html в /templates
    }

    @GetMapping("/403")
    public String accessDenied() {
        return "403"; // това сочи към 403.html в /templates
    }
}

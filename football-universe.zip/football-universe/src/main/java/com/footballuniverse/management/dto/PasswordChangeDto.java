package com.footballuniverse.management.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PasswordChangeDto {
    @NotBlank
    private String currentPassword;

    @NotBlank @Size(min = 6, max = 50)
    private String newPassword;

    @NotBlank @Size(min = 6, max = 50)
    private String confirmNewPassword;
}

package com.footballuniverse.management.service;

import com.footballuniverse.management.enums.UserRoleEnums;

public interface AdminUserService {
    void addExistingUserToTeam(Long userId, Long teamId, UserRoleEnums role);
    Long createUserInTeam(String username, String email, String rawPassword, Long teamId, UserRoleEnums role);
    void changeUserRole(Long userId, UserRoleEnums role);
    void removeUserFromTeam(Long userId);
}


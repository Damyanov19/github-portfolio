package com.footballuniverse.management.dto;

import com.footballuniverse.management.enums.AgeGroupsEnum;
import com.footballuniverse.management.enums.UserRoleEnums;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
public class UserRegistrationDto {

    @NotBlank
    @Size(min = 4, max = 40)
    private String username;

    @Email
    @NotBlank
    private String email;

    @NotBlank
    @Size(min = 6, max = 50)
    private String password;

    @NotBlank
    @Size(min = 6, max = 50)
    private String confirmPassword;


    private boolean createTeam = true;


    private String teamName;
    private String teamLocation;
    private AgeGroupsEnum teamAgeGroupsEnum;
    private String teamContacts;
    private String teamDescription;
    private String teamCountry;
    private Long teamId;
    private String position;
    private UserRoleEnums desiredRole;


}

package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.UserDto;
import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.dto.UserRegistrationDto;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Objects;

@Controller
@RequestMapping("/users")
public class UserController {

    private final UserService userService;
    private final UserRepository users;

    public UserController(UserService userService, UserRepository users) {
        this.userService = userService;
        this.users = users;
    }

    @GetMapping
    public String allUsers(Model model) {
        List<UserDto> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "users/list";
    }


 @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    @GetMapping("/{id}/edit")
    public String editUserForm(@PathVariable Long id, Model model) {
        var user = userService.findById(id).orElseThrow();
        var form = userService.toUserProfileDto(user);
        model.addAttribute("form", form);
        model.addAttribute("userId", id);
        return "users/edit";
    }

    @PreAuthorize("hasAnyRole('ADMIN','COACH')")
    @PostMapping("/{id}/edit")
    public String updateUser(@PathVariable Long id,
                             @ModelAttribute("form") UserProfileDto form,
                             RedirectAttributes ra) {
        var u = userService.findById(id).orElseThrow();
        u.setEmail(form.getEmail());
        if (form.getPosition()!=null) u.setPosition(form.getPosition());
        if (form.getNumber()!=null)   u.setNumber(form.getNumber());
        userService.save(u);
        ra.addFlashAttribute("success", "Потребителят е обновен.");
        return "redirect:/users";
    }



    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new UserRegistrationDto());
        return "/users/register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("user") UserRegistrationDto dto) {
        userService.registerUser(dto);
        return "/users/register";
    }

    @PostMapping("/{id}/approve")
    public String approve(@PathVariable Long id, RedirectAttributes ra) {
        var u = users.findById(id).orElseThrow();
        u.setApproved(true);
        users.save(u);
        ra.addFlashAttribute("success","Потребителят е одобрен.");
        return "redirect:/users";
    }

    @PostMapping("/{id}/revoke")
    public String revoke(@PathVariable Long id, RedirectAttributes ra) {
        var u = users.findById(id).orElseThrow();
        u.setApproved(false);
        users.save(u);
        ra.addFlashAttribute("success","Одобрението е отменено.");
        return "redirect:/users";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes ra) {
        users.deleteById(id);
        ra.addFlashAttribute("success","Потребителят е премахнат.");
        return "redirect:/users";
    }
}

package com.footballuniverse.management.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserProfileDto {
    private String firstName;
    private String lastName;
    private String username;   // read-only в шаблона
    private String email;
    private String position;   // ако имаш поле в UserEntity; иначе можеш да го игнорираш в update
    private String role;       // визуализация
    private String teamName;   // визуализация
    private Integer number;   // визуализация
}

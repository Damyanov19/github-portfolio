package com.footballuniverse.management.mapper; // [ADD]

import com.footballuniverse.management.dto.LineupDto;
import com.footballuniverse.management.entity.LineupEntity;
import com.footballuniverse.management.entity.LineupItemEntity;

public interface LineupMapper { // [ADD]

    public static LineupDto toDto(LineupEntity e) {
        LineupDto dto = new LineupDto();
        if (e == null) return dto;
        dto.setName(e.getName());
        dto.setNotes(e.getNotes());
        if (e.getCaptain() != null) dto.setCaptainId(e.getCaptain().getId());
        for (LineupItemEntity it : e.getItems()) {
            dto.getRoles().put(it.getPlayer().getId(), it.getRole());
            dto.getPositions().put(it.getPlayer().getId(), it.getPosition());
        }
        return dto;
    }

        public static LineupDto toDto(LineupDto existing) {
            return existing != null ? existing : new LineupDto(); // или ако мапваш от entity – върни празен DTO
        }


}

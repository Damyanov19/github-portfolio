package com.footballuniverse.management.dto;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttendanceDto {
    private Long id;
    private LocalDate date;
    private String location;
    private Long trainingId;
    private Long playerId;

    // Getters and setters
}

package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.dto.MissedTrainingDto;
import com.footballuniverse.management.entity.MissedTrainingEntity;
import com.footballuniverse.management.entity.PlayerEntity;
import com.footballuniverse.management.mapper.MissedTrainingMapper;
import com.footballuniverse.management.repository.MissedTrainingRepository;
import com.footballuniverse.management.repository.PlayerRepository;
import com.footballuniverse.management.service.MissedTrainingService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MissedTrainingServiceImpl implements MissedTrainingService {

    private final MissedTrainingRepository missedTrainingRepository;
    private final PlayerRepository playerRepository;

    public MissedTrainingServiceImpl(MissedTrainingRepository missedTrainingRepository, PlayerRepository playerRepository) {
        this.missedTrainingRepository = missedTrainingRepository;
        this.playerRepository = playerRepository;
    }

    @Override
    public MissedTrainingDto create(MissedTrainingDto dto) {
        PlayerEntity player = playerRepository.findById(dto.getPlayerId()).orElseThrow();
        MissedTrainingEntity entity = MissedTrainingMapper.toEntity(dto, player);
        return MissedTrainingMapper.toDto(missedTrainingRepository.save(entity));
    }

    @Override
    public List<MissedTrainingDto> findAll() {
        return missedTrainingRepository.findAll().stream()
                .map(MissedTrainingMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public MissedTrainingDto findById(Long id) {
        return missedTrainingRepository.findById(id)
                .map(MissedTrainingMapper::toDto)
                .orElseThrow();
    }

    @Override
    public void delete(Long id) {
        missedTrainingRepository.deleteById(id);
    }
}

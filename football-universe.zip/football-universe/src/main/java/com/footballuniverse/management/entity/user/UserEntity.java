package com.footballuniverse.management.entity.user;

import com.footballuniverse.management.entity.BaseEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.RoleEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.Authentication;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "users")
public class UserEntity extends BaseEntity {

    @Column(nullable = false, unique = true)
    private String username;

    // UserEntity
    @Column(name = "form_score")
    private Integer formScore;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String passwordHash;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id", nullable = false)
    private RoleEntity role;


    @ManyToOne
    @JoinColumn(name = "team_id")
    private TeamEntity team;

    @Column(length = 16)
    private String position;

    private Integer number;

    private String firstName;

    private String lastName;

    @Column(nullable = false)
    private boolean approved = false;
@Override
public String toString() {
    final StringBuilder sb = new StringBuilder("UserEntity{");
    sb.append("username='").append(username).append('\'');
    sb.append(", email='").append(email).append('\'');
    sb.append('}');
    return sb.toString();


}


}

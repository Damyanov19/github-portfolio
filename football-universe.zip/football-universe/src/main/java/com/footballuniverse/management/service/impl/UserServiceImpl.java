package com.footballuniverse.management.service.impl;

import com.footballuniverse.management.dto.UserDto;
import com.footballuniverse.management.dto.UserProfileDto;
import com.footballuniverse.management.dto.UserRegistrationDto;
import com.footballuniverse.management.entity.user.RoleEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.mapper.UserMapper;
import com.footballuniverse.management.repository.RoleRepository;
import com.footballuniverse.management.repository.TeamRepository;
import com.footballuniverse.management.repository.UserRepository;
import com.footballuniverse.management.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.footballuniverse.management.service.FileStorageService;

import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final TeamRepository teamRepository;
    private final FileStorageService fileStorageService;

    public UserServiceImpl(PasswordEncoder passwordEncoder,
                           UserRepository userRepository,
                           RoleRepository roleRepository,
                           TeamRepository teamRepository, FileStorageService fileStorageService) {
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.teamRepository = teamRepository;
        this.fileStorageService = fileStorageService;
    }

    @Override
    public void createUser(UserDto dto) {
        if (dto.getUsername() == null || dto.getUsername().isBlank())
            throw new IllegalArgumentException("Username is required");
        if (dto.getPassword() == null || dto.getPassword().isBlank())
            throw new IllegalArgumentException("Password is required");
        if (dto.getRole() == null)
            throw new IllegalArgumentException("Role is required");

        UserEntity user = new UserEntity();
        user.setUsername(dto.getUsername());
        user.setEmail(dto.getEmail());
        user.setPasswordHash(passwordEncoder.encode(dto.getPassword()));

        RoleEntity role = roleRepository.findByRole(dto.getRole())
                .orElseThrow(() -> new IllegalStateException("Role not found: " + dto.getRole()));
        user.setRole(role);

        userRepository.save(user);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<UserEntity> findEntityByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream()
                .map(UserMapper::toDto)
                .toList();
    }

    @Override
    public Optional<UserEntity> findById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public UserProfileDto toUserProfileDto(UserEntity u) {
        UserProfileDto dto = new UserProfileDto();
        dto.setUsername(u.getUsername());
        dto.setEmail(u.getEmail());
        dto.setPosition(u.getPosition());
        dto.setNumber(u.getNumber());
        if (u.getRole() != null) dto.setRole(u.getRole().getRole().name());
        if (u.getTeam() != null) dto.setTeamName(u.getTeam().getName());
        return dto;
    }

    @Override
    public void applyProfile(UserEntity u, UserProfileDto dto) {
        u.setEmail(dto.getEmail());
        if (dto.getPosition() != null) u.setPosition(dto.getPosition());
        if (dto.getNumber() != null)   u.setNumber(dto.getNumber());
    }

    @Override
    public UserDto getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .map(UserMapper::toDto)
                .orElseThrow(() -> new NoSuchElementException("User not found: " + username));
    }


    @Override
    public boolean userExists(String username, String email) {
        return userRepository.existsByUsername(username) || userRepository.existsByEmail(email);
    }


    @Override
    @Transactional
    public void registerUser(UserRegistrationDto dto) {
        if (dto == null) throw new IllegalArgumentException("Липсват данни за регистрация.");
        if (isBlank(dto.getUsername())) throw new IllegalArgumentException("Въведи потребителско име.");
        if (isBlank(dto.getEmail())) throw new IllegalArgumentException("Въведи имейл.");
        if (isBlank(dto.getPassword())) throw new IllegalArgumentException("Въведи парола.");
        if (!dto.getPassword().equals(dto.getConfirmPassword())) {
            throw new IllegalArgumentException("Паролите не съвпадат.");
        }
        if (userRepository.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException("Потребителското име е заето.");
        }
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Имейлът е зает.");
        }

        UserEntity u = new UserEntity();
        u.setUsername(dto.getUsername().trim());
        u.setEmail(dto.getEmail().trim());
        u.setPasswordHash(passwordEncoder.encode(dto.getPassword()));


        if (dto.isCreateTeam()) {
            if (isBlank(dto.getTeamName())) {
                throw new IllegalArgumentException("Името на отбора е задължително.");
            }
            TeamEntity t = new TeamEntity();
            t.setName(dto.getTeamName().trim());
            t.setCity(dto.getTeamLocation());
            t.setDescription(dto.getTeamDescription());
            t.setContacts(dto.getTeamContacts());
            t.setAgeGroupsEnum(dto.getTeamAgeGroupsEnum());
            t.setCountry(
                    (dto.getTeamCountry() != null && !dto.getTeamCountry().isBlank())
                            ? dto.getTeamCountry().trim()
                            : "Bulgaria");
            teamRepository.save(t);


            RoleEntity adminRole = roleRepository.findByRole(UserRoleEnums.ADMIN).orElseThrow();
            u.setRole(adminRole);
            u.setTeam(t);
            u.setApproved(true);
            t.setContacts(dto.getTeamContacts());
        }
        else {

            if (dto.getTeamId() == null) throw new IllegalArgumentException("Избери отбор");
            if (dto.getDesiredRole() == null || dto.getDesiredRole() == UserRoleEnums.ADMIN)
                throw new IllegalArgumentException("Избери роля: COACH или PLAYER");

            TeamEntity t = teamRepository.findById(dto.getTeamId())
                    .orElseThrow(() -> new IllegalArgumentException("Невалиден отбор"));
            RoleEntity r = roleRepository.findByRole(dto.getDesiredRole()).orElseThrow();

            u.setTeam(t);
            u.setRole(r);

            if (dto.getDesiredRole() == UserRoleEnums.PLAYER) {
                u.setPosition(dto.getPosition());
            }
            u.setApproved(false);
        }


        userRepository.save(u);
    }



    @Override
    @Transactional
    public void addMemberToMyTeam(String usernameOrEmail,
                                  UserRoleEnums role,
                                  String position,
                                  String currentAdminUsername) {
        if (role == null || role == UserRoleEnums.ADMIN)
            throw new IllegalArgumentException("Ролята трябва да е COACH или PLAYER.");

        UserEntity admin = userRepository.findByUsername(currentAdminUsername)
                .orElseThrow(() -> new IllegalStateException("Admin not found"));
        TeamEntity team = admin.getTeam();
        if (team == null) throw new IllegalStateException("Админът няма свързан отбор.");

        UserEntity u = userRepository
                .findByUsernameIgnoreCaseOrEmailIgnoreCase(usernameOrEmail, usernameOrEmail)
                .orElse(null);

        if (u == null) {

            u = new UserEntity();

            if (usernameOrEmail.contains("@")) {

                u.setEmail(usernameOrEmail.trim());
                String base = usernameOrEmail.substring(0, usernameOrEmail.indexOf('@'))
                        .replaceAll("[^a-zA-Z0-9._-]", "");
                String candidate = base.isBlank() ? "user" : base;
                String uname = candidate;
                int i = 1;
                while (userRepository.existsByUsername(uname)) {
                    uname = candidate + i++;
                }
                u.setUsername(uname);
            } else {
                u.setUsername(usernameOrEmail.trim());
                u.setEmail(u.getUsername() + "@example.com");
            }

            String raw = "Temp-" + UUID.randomUUID().toString().substring(0, 8);
            u.setPasswordHash(passwordEncoder.encode(raw));

        } else {

            if (u.getTeam() != null && !u.getTeam().getId().equals(team.getId())) {
                throw new IllegalStateException("Потребителят вече е в друг отбор.");
            }
        }

        RoleEntity r = roleRepository.findByRole(role).orElseThrow();
        u.setRole(r);
        u.setTeam(team);

       u.setPosition(position);

        userRepository.save(u);
    }


    @Override
    @Transactional
    public void changeMemberRole(Long memberId, UserRoleEnums newRole, String currentAdminUsername) {
        if (newRole == null || newRole == UserRoleEnums.ADMIN)
            throw new IllegalArgumentException("Ролята трябва да е COACH или PLAYER.");

        UserEntity admin = userRepository.findByUsername(currentAdminUsername)
                .orElseThrow(() -> new IllegalStateException("Admin not found"));

        UserEntity member = userRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Потребителят не е намерен."));


        if (member.getTeam() == null || admin.getTeam() == null ||
                !member.getTeam().getId().equals(admin.getTeam().getId())) {
            throw new IllegalStateException("Нямаш права над този потребител.");
        }


        if (member.getUsername().equals(currentAdminUsername))
            throw new IllegalStateException("Не можеш да променяш собствената си роля тук.");

        RoleEntity r = roleRepository.findByRole(newRole).orElseThrow();
        member.setRole(r);
        userRepository.save(member);
    }

    @Override
    @Transactional
    public void removeMember(Long memberId, String currentAdminUsername) {
        UserEntity admin = userRepository.findByUsername(currentAdminUsername)
                .orElseThrow(() -> new IllegalStateException("Admin not found"));

        UserEntity member = userRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Потребителят не е намерен."));

        if (member.getTeam() == null || admin.getTeam() == null ||
                !member.getTeam().getId().equals(admin.getTeam().getId())) {
            throw new IllegalStateException("Нямаш права над този потребител.");
        }


        if (member.getUsername().equals(currentAdminUsername))
            throw new IllegalStateException("Не можеш да премахнеш себе си.");


        boolean isAdminRole = member.getRole() != null && member.getRole().getRole() == UserRoleEnums.ADMIN;
        if (isAdminRole) {
            long admins = userRepository.countByTeamIdAndRole_Role(admin.getTeam().getId(), UserRoleEnums.ADMIN);
            if (admins <= 1) throw new IllegalStateException("Не можеш да премахнеш единствения администратор.");
        }


        member.setTeam(null);
        userRepository.save(member);
        userRepository.delete(member);
    }
    private static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }

    @Override
    @Transactional(readOnly = true)
    public UserProfileDto getMyProfile(String username) {
        var u = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Потребителят не е намерен."));

        UserProfileDto dto = new UserProfileDto();
        dto.setUsername(u.getUsername());
        dto.setEmail(u.getEmail());

        try {
            var m = u.getClass().getMethod("getPosition");
            Object pos = m.invoke(u);
            dto.setPosition(pos != null ? String.valueOf(pos) : null);
        } catch (Exception ignored) {
            dto.setPosition(null);
        }

        dto.setRole(u.getRole() != null ? u.getRole().getRole().name() : null);
        dto.setTeamName(u.getTeam() != null ? u.getTeam().getName() : null);
        return dto;
    }

    @Override
    @Transactional
    public void updateMyProfile(String username, UserProfileDto dto) {
        if (dto == null) throw new IllegalArgumentException("Липсват данни.");
        var u = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Потребителят не е намерен."));

        String newEmail = Optional.ofNullable(dto.getEmail()).map(String::trim).orElse("");
        if (newEmail.isEmpty()) {
            throw new IllegalArgumentException("Имейлът е задължителен.");
        }

        boolean emailTakenByOther =
                userRepository.existsByEmail(newEmail) && !Objects.equals(newEmail, u.getEmail());
        if (emailTakenByOther) {
            throw new IllegalArgumentException("Имейлът е зает от друг потребител.");
        }
        u.setEmail(newEmail);


        try {
            var setter = u.getClass().getMethod("setPosition", String.class);
            setter.invoke(u, dto.getPosition());
        } catch (NoSuchMethodException ignored) {
        } catch (Exception e) {
            throw new IllegalStateException("Неуспешно обновяване на позицията.", e);
        }

        userRepository.save(u);
    }


    @Override
    @Transactional
    public void changeMyPassword(String username, String oldPass, String newPass) {
        if (oldPass == null || oldPass.isBlank()) {
            throw new IllegalArgumentException("Въведи текуща парола.");
        }
        if (newPass == null || newPass.length() < 6) {
            throw new IllegalArgumentException("Новата парола трябва да е поне 6 символа.");
        }

        var u = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Потребителят не е намерен."));

        if (!passwordEncoder.matches(oldPass, u.getPasswordHash())) {
            throw new IllegalArgumentException("Грешна текуща парола.");
        }
        if (passwordEncoder.matches(newPass, u.getPasswordHash())) {
            throw new IllegalArgumentException("Новата парола съвпада с текущата.");
        }

        u.setPasswordHash(passwordEncoder.encode(newPass));
        userRepository.save(u);
    }

    @Override
    @Transactional
    public UserEntity save(UserEntity user) {
        return userRepository.save(user);
    }

}


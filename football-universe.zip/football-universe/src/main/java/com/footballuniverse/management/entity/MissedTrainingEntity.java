package com.footballuniverse.management.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@Table(name = "missed_trainings")
@NoArgsConstructor
public class MissedTrainingEntity extends BaseEntity {

    @ManyToOne(optional = false)
    private PlayerEntity player;

    @Column(nullable = false)
    private String reason;

    @Column(nullable = false)
    private String location;

    @Column(nullable = false)
    private LocalDate date;
}

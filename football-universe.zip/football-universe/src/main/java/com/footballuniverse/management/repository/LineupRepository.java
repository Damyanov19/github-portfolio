package com.footballuniverse.management.repository; // [ADD]

import com.footballuniverse.management.entity.LineupEntity;
import com.footballuniverse.management.entity.LineupItemEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LineupRepository extends JpaRepository<LineupEntity, Long> { // [ADD]
    Optional<LineupEntity> findByEventIdAndTeamId(Long eventId, Long teamId);

}

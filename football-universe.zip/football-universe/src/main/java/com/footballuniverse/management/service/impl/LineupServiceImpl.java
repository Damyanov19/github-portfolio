package com.footballuniverse.management.service.impl; // [ADD]

import com.footballuniverse.management.dto.LineupDto;
import com.footballuniverse.management.entity.*;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.EventType;
import com.footballuniverse.management.enums.LineupRole;
import com.footballuniverse.management.repository.*;
import com.footballuniverse.management.service.LineupService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class LineupServiceImpl implements LineupService { // [ADD]

    private final EventRepository events;
    private final UserRepository users;
    private final LineupRepository lineups;
    private final LineupItemRepository items;

    public LineupServiceImpl(EventRepository events, UserRepository users, LineupRepository lineups, LineupItemRepository items) {
        this.events = events;
        this.users = users;
        this.lineups = lineups;
        this.items = items;
    }

    @Override
    public LineupEntity getForEvent(Long eventId, Long teamId) {
        return lineups.findByEventIdAndTeamId(eventId, teamId).orElse(null);
    }

    @Transactional
    public LineupEntity getOrCreate(Long eventId, Long teamId, Long createdByUserId) {
        return lineups.findByEventIdAndTeamId(eventId, teamId)
                .orElseGet(() -> {
                    var e = events.findById(eventId).orElseThrow();
                    var creator = users.findById(createdByUserId).orElseThrow();
                    var l = new LineupEntity();
                    l.setEvent(e);
                    l.setTeam(e.getTeam());
                    l.setCreatedBy(creator);
                    l.setName("Състав за " + e.getId()); // или каквото имаш
                    return lineups.save(l);
                });
    }

    @Transactional
    public void saveItems(Long lineupId, List<LineupItemEntity> newItems, Long captainUserId) {
        var l = lineups.findById(lineupId).orElseThrow();
        items.deleteAll(items.findAllByLineupIdOrderByOrderNoAsc(lineupId));
        newItems.forEach(i -> i.setLineup(l));
        items.saveAll(newItems);
        if (captainUserId != null) {
            l.setCaptain(users.findById(captainUserId).orElse(null));
        }
        lineups.save(l);
    }
    @Override
    @Transactional
    public void saveForEvent(Long eventId, TeamEntity team, String createdByUsername, LineupDto dto) {
        EventEntity e = events.findById(eventId).orElseThrow(
                () -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Събитието не съществува"));

        if (!Objects.equals(e.getTeam().getId(), team.getId()))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Нямате права за този мач");

        if (e.getType() != EventType.MATCH)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Състави са само за мачове");

        long starters = dto.getRoles().values().stream().filter(r -> r == LineupRole.STARTER).count();
        if (starters != 11)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Стартовите трябва да са точно 11 (текущо: " + starters + ")");

        if (dto.getCaptainId() == null ||
                dto.getRoles().getOrDefault(dto.getCaptainId(), LineupRole.NONE) != LineupRole.STARTER)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Капитанът трябва да е сред титулярите.");

        var lineup = lineups.findByEventIdAndTeamId(eventId, team.getId()).orElseGet(() -> {
            LineupEntity nl = new LineupEntity();
            nl.setTeam(team);
            nl.setEvent(e);
            users.findByUsername(createdByUsername).ifPresent(nl::setCreatedBy);
            return nl;
        });

        lineup.setName(dto.getName());
        lineup.setNotes(dto.getNotes());
        lineup.setCaptain(users.findById(dto.getCaptainId()).orElse(null));

        lineup.getItems().clear();
        int order = 1;
        for (var entry : dto.getRoles().entrySet()) {
            Long playerId = entry.getKey();
            LineupRole role = entry.getValue();
            if (role == LineupRole.NONE) continue;

            UserEntity p = users.findById(playerId).orElse(null);
            if (p == null) continue;
            if (p.getTeam() == null || !Objects.equals(p.getTeam().getId(), team.getId())) continue;

            LineupItemEntity it = new LineupItemEntity();
            it.setLineup(lineup);
            it.setPlayer(p);
            it.setRole(role);
            it.setPosition(dto.getPositions().get(playerId));
            it.setOrderNo(order++);
            lineup.getItems().add(it);
        }

        lineups.save(lineup);

        var toUpdate = new ArrayList<UserEntity>();
        for (var it : lineup.getItems()) {
            if (it == null || it.getPlayer() == null) continue;


            if (it.getRole() != LineupRole.STARTER && it.getRole() != LineupRole.BENCH) continue;

            String pos = it.getPosition();
            if (pos == null || pos.isBlank()) continue;

            var uOpt = users.findById(it.getPlayer().getId());
            if (uOpt.isEmpty()) continue;

            var u = uOpt.get();
            if (u.getTeam() == null || !u.getTeam().getId().equals(team.getId())) continue;

            String normalized = pos.trim().toUpperCase();

            u.setPosition(normalized);
            toUpdate.add(u);
        }
        if (!toUpdate.isEmpty()) {
            users.saveAll(toUpdate);
        }
    }

    @Override
    @Transactional
    public void deleteForEvent(Long eventId, Long teamId) {
        lineups.findByEventIdAndTeamId(eventId, teamId).ifPresent(lineups::delete);
    }
}

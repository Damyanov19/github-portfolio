package com.footballuniverse.management.dto;
import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.enums.UserRoleEnums;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {
    private Long id;
    private String username;
    private String email;
    private UserRoleEnums role;;
    private String team;
    private String password;
    private Boolean approved;

    public UserEntity orElseThrow() {
    return null;}


}

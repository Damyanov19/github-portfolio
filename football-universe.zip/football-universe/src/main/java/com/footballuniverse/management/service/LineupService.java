package com.footballuniverse.management.service; // [ADD]

import com.footballuniverse.management.dto.LineupDto;
import com.footballuniverse.management.entity.LineupEntity;
import com.footballuniverse.management.entity.LineupItemEntity;
import com.footballuniverse.management.entity.TeamEntity;

import java.util.List;

public interface LineupService { // [ADD]
    LineupEntity getForEvent(Long eventId, Long teamId);
    void saveForEvent(Long eventId, TeamEntity team, String createdByUsername, LineupDto dto);

    LineupEntity getOrCreate(Long eventId, Long teamId, Long createdByUserId);
    void saveItems(Long lineupId, List<LineupItemEntity> items, Long captainUserId);
    void deleteForEvent(Long eventId, Long teamId);

}

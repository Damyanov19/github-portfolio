package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.RoleDto;

import java.util.List;

public interface RoleService {
    List<RoleDto> getAllRoles();
    RoleDto getRoleByName(String name);
}

package com.footballuniverse.management.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "position")
public class PositionEntity extends BaseEntity{
    @Column(nullable = false, unique = true)
    private String name; // Пример: "Goalkeeper", "Defender", "Midfielder", "Striker"

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }
}

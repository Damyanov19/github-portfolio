package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.RoleDto;
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.service.RoleService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/roles")
public class RoleController {

    private final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @GetMapping
    public String allRoles(Model model) {
        List<RoleDto> roles = roleService.getAllRoles();
        model.addAttribute("roles", new UserRoleEnums[]{UserRoleEnums.COACH, UserRoleEnums.PLAYER});
        return "roles/all";
    }
}

package com.footballuniverse.management.web;

import com.footballuniverse.management.entity.user.UserEntity;
import com.footballuniverse.management.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.NoSuchElementException;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final UserRepository userRepository;

    @GetMapping("/dashboard")
    public String dashboard(Authentication auth) {
        UserEntity u = userRepository.findByUsername(auth.getName())
                .orElseThrow(() -> new NoSuchElementException("User not found: " + auth.getName()));

        switch (u.getRole().getRole()) {
            case ADMIN: return "dashboard/admin";
            case COACH: return "dashboard/coach";
            default:    return "dashboard/player";
        }
    }

}

package com.footballuniverse.management.dto;

import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MatchDto {

    private Long id;
    private LocalDateTime matchDate;
    private String opponent;
    private String location;
    private Integer teamGoals;
    private Integer opponentGoals;
    private Long teamId;

    // Getters and Setters
}

package com.footballuniverse.management.entity;

import com.footballuniverse.management.entity.user.UserEntity;
import jakarta.persistence.*;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "players")
public class PlayerEntity extends BaseEntity {
    private String firstName;
    private String lastName;

    private String position; // e.g. Forward, Midfielder, etc.

    private int jerseyNumber;

    private LocalDate birthDate;

    private boolean active;

    @ManyToOne
    @JoinColumn(name = "team_id", nullable = false)
    private TeamEntity team;

    @OneToOne
    @JoinColumn(name = "user_id")
    private UserEntity user; // optional login account

    // Constructors
    public PlayerEntity() {}

    public String getName() {
        return firstName + " " + lastName;
    }
}

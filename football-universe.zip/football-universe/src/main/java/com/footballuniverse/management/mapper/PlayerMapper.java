package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.PlayerDto;
import com.footballuniverse.management.entity.PlayerEntity;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.user.UserEntity;
import org.springframework.stereotype.Component;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
@Component
public interface PlayerMapper {

    public static PlayerDto toDto(PlayerEntity player) {
        PlayerDto dto = new PlayerDto();
        dto.setId(player.getId());
        dto.setFirstName(player.getFirstName());
        dto.setLastName(player.getLastName());
        dto.setPosition(player.getPosition());
        dto.setJerseyNumber(player.getJerseyNumber());
        dto.setBirthDate(player.getBirthDate());
        dto.setActive(player.isActive());
        dto.setTeamId(player.getTeam().getId());
        dto.setUserId(player.getUser() != null ? player.getUser().getId() : null);
        return dto;
    }

    public static PlayerEntity toEntity(PlayerDto dto, TeamEntity team, UserEntity user) {
        PlayerEntity player = new PlayerEntity();
        player.setId(dto.getId());
        player.setFirstName(dto.getFirstName());
        player.setLastName(dto.getLastName());
        player.setPosition(dto.getPosition());
        player.setJerseyNumber(dto.getJerseyNumber());
        player.setBirthDate(dto.getBirthDate());
        player.setActive(dto.isActive());
        player.setTeam(team);
        player.setUser(user);
        return player;
    }
}

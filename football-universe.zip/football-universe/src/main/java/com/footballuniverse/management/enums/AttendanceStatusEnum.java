package com.footballuniverse.management.enums;

public enum AttendanceStatusEnum {
    YES, NO, UNDECIDED
}

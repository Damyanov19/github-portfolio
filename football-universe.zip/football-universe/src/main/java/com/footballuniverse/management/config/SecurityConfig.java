package com.footballuniverse.management.config;

import com.footballuniverse.management.security.FootballUserDetailsService;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.security.autoconfigure.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final FootballUserDetailsService userDetailsService;
    private final PasswordEncoder passwordEncoder;

    public SecurityConfig(FootballUserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {
        this.userDetailsService = userDetailsService;
        this.passwordEncoder = passwordEncoder;
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
                http.getSharedObject(AuthenticationManagerBuilder.class);

        authenticationManagerBuilder
                .userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder);

        return authenticationManagerBuilder.build();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
                        .requestMatchers("/", "/login", "/register", "/users/register", "/css/**", "/js/**", "/images/**").permitAll()
                        .requestMatchers(HttpMethod.GET,  "/attendance/manage/*/rsvp").hasAnyRole("PLAYER","COACH","ADMIN")
                        .requestMatchers(HttpMethod.POST, "/attendance/manage/*/rsvp").hasAnyRole("PLAYER","COACH","ADMIN")
                        .requestMatchers("/attendance/manage/**").hasAnyRole("ADMIN","COACH")
                        .requestMatchers("/dashboard/**", "/profile/**").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers("/events/**").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers("/attendance/**").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers("/players/**").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers("/team/players").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers("/settings/**").hasAnyRole("ADMIN")
                        .requestMatchers("/team/settings/**").hasRole("ADMIN")
                        .requestMatchers("/matches/**").hasAnyRole("ADMIN","COACH")
                        .requestMatchers("/stats/**").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers("/team/messages").authenticated()
                        .requestMatchers("/team/messages/new", "/team/messages/**").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers(HttpMethod.POST, "/team/messages/*/comments").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers(HttpMethod.GET,  "/team/messages/*").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers("/events/*/lineup", "/events/*/lineup/").hasAnyRole("ADMIN","COACH","PLAYER")
                        .requestMatchers(HttpMethod.GET, "/events/*/lineup/edit").hasAnyRole("ADMIN","COACH")
                        .requestMatchers(HttpMethod.POST, "/events/*/lineup").hasAnyRole("ADMIN","COACH")
                        .requestMatchers(HttpMethod.POST, "/events/*/lineup/delete").hasAnyRole("ADMIN","COACH")
                        .requestMatchers(HttpMethod.POST, "/profile/**").hasAnyRole("ADMIN","COACH")
                        .requestMatchers(HttpMethod.GET, "/profile/edit").hasAnyRole("ADMIN","COACH")
                        .requestMatchers(HttpMethod.POST, "/profile/edit").hasAnyRole("ADMIN","COACH")
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login").permitAll()
                        .loginProcessingUrl("/login")
                        .failureUrl("/login?error=true")
                        .defaultSuccessUrl("/dashboard", true)
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout=true")
                        .invalidateHttpSession(true)
                        .deleteCookies("JSESSIONID")
                )
                .exceptionHandling(ex -> ex.accessDeniedPage("/403"));

        return http.build();
    }

}

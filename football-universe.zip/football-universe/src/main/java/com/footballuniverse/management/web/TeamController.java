package com.footballuniverse.management.web;

import com.footballuniverse.management.dto.TeamDto;
import com.footballuniverse.management.entity.TeamEntity;               // [NEW]
import com.footballuniverse.management.entity.user.UserEntity;        // [NEW]
import com.footballuniverse.management.enums.UserRoleEnums;
import com.footballuniverse.management.repository.TeamRepository;     // [NEW]
import com.footballuniverse.management.repository.UserRepository;     // [NEW]
import com.footballuniverse.management.service.FileStorageService;    // [NEW]
import com.footballuniverse.management.service.TeamService;
import com.footballuniverse.management.service.UserService;
import org.springframework.http.MediaType;                              // [NEW]
import org.springframework.security.access.prepost.PreAuthorize;      // [NEW]
import org.springframework.security.core.Authentication;               // [NEW]
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;                 // [NEW]
import org.springframework.web.servlet.mvc.support.RedirectAttributes; // [NEW]

@Controller
@RequestMapping("/team")
public class TeamController {

    private final TeamService teamService;
    private final UserRepository userRepository;
    private final TeamRepository teamRepository;
    private final FileStorageService fileStorageService;

    private final UserService userService;

    public TeamController(TeamService teamService,
                          UserRepository userRepository,
                          TeamRepository teamRepository,
                          FileStorageService fileStorageService, UserService userService) {
        this.teamService = teamService;
        this.userRepository = userRepository;
        this.teamRepository = teamRepository;
        this.fileStorageService = fileStorageService;
        this.userService = userService;
    }


    @GetMapping
    public String allTeams(Model model) {
        model.addAttribute("team", teamService.getAllTeams());
        return "team/all";
    }

    @GetMapping("/add")
    public String addTeamForm(Model model) {
        model.addAttribute("team", new TeamDto());
        return "team/add";
    }

    @PostMapping("/add")
    public String addTeam(@ModelAttribute TeamDto teamDto) {
        teamService.save(teamDto);
        return "redirect:/team";
    }

    // ========================================================================
    // [NEW]  Настройки на Моя Отбор (само за ADMIN на отбора)
    // ========================================================================

    // помощен метод: текущият отбор на логнатия потребител
    private TeamEntity currentTeam(Authentication auth) {
        UserEntity u = userRepository.findByUsername(auth.getName()).orElseThrow();
        return u.getTeam();
    }

    /**
     * Екран с настройки на отбора (качване на емблема и т.н.)
     * Достъпен само за ADMIN.
     */
    @GetMapping("/settings")
    @PreAuthorize("hasRole('ADMIN')") // само админ на отбора
    public String settings(Authentication auth, Model model) {
        Long teamId = currentTeam(auth).getId();
        model.addAttribute("team", currentTeam(auth));
        model.addAttribute("members", userRepository.findAllByTeamIdOrderByUsernameAsc(teamId));
        model.addAttribute("roles", new UserRoleEnums[]{UserRoleEnums.COACH, UserRoleEnums.PLAYER});
        return "team/settings"; // създай templates/teams/settings.html
    }

    // [ADD] – добавяне на член (по username или email) + роля + позиция (по желание)
    @PostMapping("/settings/add")
    @PreAuthorize("hasRole('ADMIN')")
    public String addMember(@RequestParam("usernameOrEmail") String usernameOrEmail,
                            @RequestParam("role") UserRoleEnums role,
                            @RequestParam(value="position", required=false) String position,
                            Authentication auth,
                            RedirectAttributes ra) {
        try {
            userService.addMemberToMyTeam(usernameOrEmail, role, position, auth.getName());
            ra.addFlashAttribute("success", "Членът е добавен.");
        } catch (Exception ex) {
            ra.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/team/settings";
    }

    @PostMapping("/settings/{id}/role")
    @PreAuthorize("hasRole('ADMIN')")
    public String changeRole(@PathVariable Long id,
                             @RequestParam("role") UserRoleEnums role,
                             Authentication auth,
                             RedirectAttributes ra) {
        try {
            userService.changeMemberRole(id, role, auth.getName());
            ra.addFlashAttribute("success", "Ролята е променена.");
        } catch (Exception ex) {
            ra.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/team/settings";
    }

    // [ADD] – премахване от отбор
    @PostMapping("/settings/{id}/remove")
    @PreAuthorize("hasRole('ADMIN')")
    public String removeMember(@PathVariable Long id,
                               Authentication auth,
                               RedirectAttributes ra) {
        try {
            userService.removeMember(id, auth.getName());
            ra.addFlashAttribute("success", "Потребителят е премахнат от отбора.");
        } catch (Exception ex) {
            ra.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/team/settings";
    }

    @PostMapping("/settings/name")
    @PreAuthorize("hasRole('ADMIN')")
    public String updateTeamName(@RequestParam("name") String name,
                                 Authentication auth,
                                 RedirectAttributes ra) {
        String newName = name == null ? "" : name.trim();
        if (newName.length() < 3 || newName.length() > 60) {
            ra.addFlashAttribute("error", "Името трябва да е между 3 и 60 символа.");
            return "redirect:/team/settings";
        }

        var team = currentTeam(auth);
        team.setName(newName);
        teamRepository.save(team);

        ra.addFlashAttribute("success", "Името на отбора е обновено.");
        return "redirect:/team/settings";
    }
    /**
     * Качване на емблема (лого) от екрана с настройки
     */
    @PostMapping(value = "/settings/logo", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('ADMIN')")
    public String uploadLogo(@RequestParam("file") MultipartFile file,
                             Authentication auth,
                             RedirectAttributes ra) {
        if (file == null || file.isEmpty()) {
            ra.addFlashAttribute("error", "Качи изображение (PNG/JPG).");
            return "redirect:/team/settings";
        }

        // запис на файла към диска → връщаме URL (/uploads/...)
        String url = fileStorageService.storeTeamCrest(file);

        TeamEntity team = currentTeam(auth);

        // Ако имаш поле crestUrl в TeamEntity — разкоментирай следващия ред:
         team.setCrestUrl(url);

        // Ако още нямаш crestUrl, можеш временно да добавиш линка към description:
        if (team.getDescription() == null || team.getDescription().isBlank()) {
            team.setDescription("Crest: " + url);
        } else if (!team.getDescription().contains("Crest:")) {
            team.setDescription(team.getDescription() + "\nCrest: " + url);
        }

        teamRepository.save(team);
        ra.addFlashAttribute("success", "Емблемата е обновена.");
        return "redirect:/team/settings";
    }
}

package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.TrainingDto;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.TrainingEntity;

public interface TrainingMapper {

    public static TrainingDto toDto(TrainingEntity entity) {
        TrainingDto dto = new TrainingDto();
        dto.setId(entity.getId());
        dto.setTrainingDateTime(entity.getDateTime());
        dto.setLocation(entity.getLocation());
        dto.setTeamId(entity.getTeam().getId());
        return dto;
    }

    public static TrainingEntity toEntity(TrainingDto dto, TeamEntity team) {
        TrainingEntity entity = new TrainingEntity();
        entity.setId(dto.getId());
        entity.setDateTime(dto.getTrainingDateTime());
        entity.setLocation(dto.getLocation());
        entity.setTeam(team);
        return entity;
    }
}

package com.footballuniverse.management.service;

import com.footballuniverse.management.dto.TrainingDto;
import com.footballuniverse.management.entity.TeamEntity;
import com.footballuniverse.management.entity.TrainingEntity;

import java.util.List;

public interface TrainingService {
    List<TrainingDto> getAllTrainingsByTeam(Long teamId);
    void saveTraining(TrainingDto trainingDto);
    TrainingDto getTrainingById(Long id);
    void deleteTraining(Long id);

}

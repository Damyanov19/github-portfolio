package com.footballuniverse.management.mapper;

import com.footballuniverse.management.dto.RoleDto;
import com.footballuniverse.management.entity.user.RoleEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface RoleMapper {
    public static RoleDto toDto(RoleEntity entity) {
        RoleDto dto = new RoleDto();
        dto.setId(entity.getId());
        dto.setDesiredRole(entity.getRole());
        return dto;
    }
}

package com.footballuniverse.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballUniverseApplicationTests {

	@Test
	void contextLoads() {
	}

}
